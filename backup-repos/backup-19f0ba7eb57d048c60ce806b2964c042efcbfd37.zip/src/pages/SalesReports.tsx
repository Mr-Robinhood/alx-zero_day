import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Loader2, FileText, Calendar, DollarSign, Eye, ArrowLeft } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Navigate } from 'react-router-dom';

interface Session {
  id: string;
  user_id: string;
  start_time: string;
  end_time: string | null;
  status: string;
  created_at: string;
  user_profile?: {
    full_name: string;
  };
}

interface Sale {
  id: string;
  session_id: string;
  product_id: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  sale_time: string;
  product?: {
    name: string;
    barcode: string;
  };
}

interface SessionWithRevenue extends Session {
  total_revenue: number;
  items_count: number;
}

const SalesReports = () => {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [sessions, setSessions] = useState<SessionWithRevenue[]>([]);
  const [selectedSession, setSelectedSession] = useState<SessionWithRevenue | null>(null);
  const [sessionSales, setSessionSales] = useState<Sale[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingSales, setLoadingSales] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Only admins can access this page
  if (profile?.role !== 'admin') {
    return <Navigate to="/" replace />;
  }

  useEffect(() => {
    fetchSessions();
  }, []);

  const fetchSessions = async () => {
    try {
      // First get all sessions
      const { data: sessionsData, error: sessionsError } = await supabase
        .from('sessions')
        .select('*')
        .order('start_time', { ascending: false });

      if (sessionsError) throw sessionsError;

      // Then get sales data and user profiles for each session
      const sessionsWithRevenue: SessionWithRevenue[] = [];
      
      for (const session of sessionsData || []) {
        // Get sales data for this session
        const { data: salesData, error: salesError } = await supabase
          .from('sales')
          .select('total_price')
          .eq('session_id', session.id);

        if (salesError) {
          console.error('Error fetching sales for session:', session.id, salesError);
          continue;
        }

        // Get user profile for this session
        const { data: profileData, error: profileError } = await supabase
          .from('profiles')
          .select('full_name')
          .eq('user_id', session.user_id)
          .single();

        if (profileError) {
          console.error('Error fetching profile for session:', session.id, profileError);
        }

        const totalRevenue = salesData?.reduce((sum, sale) => sum + parseFloat(sale.total_price.toString()), 0) || 0;
        const itemsCount = salesData?.length || 0;

        sessionsWithRevenue.push({
          ...session,
          user_profile: profileData || undefined,
          total_revenue: totalRevenue,
          items_count: itemsCount,
        });
      }

      setSessions(sessionsWithRevenue);
    } catch (error) {
      console.error('Error fetching sessions:', error);
      toast({
        title: "Error",
        description: "Failed to load sales sessions.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchSessionSales = async (sessionId: string) => {
    setLoadingSales(true);
    try {
      const { data, error } = await supabase
        .from('sales')
        .select(`
          *,
          products(name, barcode)
        `)
        .eq('session_id', sessionId)
        .order('sale_time', { ascending: false });

      if (error) throw error;
      setSessionSales(data || []);
    } catch (error) {
      console.error('Error fetching session sales:', error);
      toast({
        title: "Error",
        description: "Failed to load session sales.",
        variant: "destructive",
      });
    } finally {
      setLoadingSales(false);
    }
  };

  const handleViewSession = (session: SessionWithRevenue) => {
    setSelectedSession(session);
    setIsDialogOpen(true);
    fetchSessionSales(session.id);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  const formatDuration = (startTime: string, endTime: string | null) => {
    if (!endTime) return 'Ongoing';
    
    const start = new Date(startTime);
    const end = new Date(endTime);
    const diffMs = end.getTime() - start.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    
    if (diffHours > 0) {
      return `${diffHours}h ${diffMinutes}m`;
    }
    return `${diffMinutes}m`;
  };

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-8 bg-muted rounded w-1/4"></div>
        <div className="h-96 bg-muted rounded-lg"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center space-x-3">
            <FileText className="h-8 w-8 text-primary" />
            <span>Sales Reports</span>
          </h1>
          <p className="text-muted-foreground mt-1">
            View detailed sales sessions and transaction history
          </p>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid gap-6 md:grid-cols-3">
        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Sessions
            </CardTitle>
            <Calendar className="h-5 w-5 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">
              {sessions.length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              All time sessions
            </p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Revenue
            </CardTitle>
            <DollarSign className="h-5 w-5 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-success">
              {formatCurrency(sessions.reduce((sum, session) => sum + session.total_revenue, 0))}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              All time sales
            </p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Active Sessions
            </CardTitle>
            <Calendar className="h-5 w-5 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-warning">
              {sessions.filter(s => s.status === 'active').length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Currently ongoing
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Sessions Table */}
      <Card className="medical-card">
        <CardHeader>
          <CardTitle>Sales Sessions</CardTitle>
          <CardDescription>
            All sales sessions with revenue and duration information
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date & Time</TableHead>
                <TableHead>Cashier</TableHead>
                <TableHead>Duration</TableHead>
                <TableHead>Items Sold</TableHead>
                <TableHead>Revenue</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sessions.map((session) => (
                <TableRow key={session.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">
                        {new Date(session.start_time).toLocaleDateString()}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {new Date(session.start_time).toLocaleTimeString()}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="font-medium">
                    {session.user_profile?.full_name || 'Unknown'}
                  </TableCell>
                  <TableCell>
                    {formatDuration(session.start_time, session.end_time)}
                  </TableCell>
                  <TableCell className="text-center">
                    {session.items_count}
                  </TableCell>
                  <TableCell className="font-medium text-success">
                    {formatCurrency(session.total_revenue)}
                  </TableCell>
                  <TableCell>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      session.status === 'active' 
                        ? 'bg-warning/20 text-warning' 
                        : 'bg-success/20 text-success'
                    }`}>
                      {session.status}
                    </span>
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleViewSession(session)}
                      className="h-8 w-8 p-0"
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Session Details Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <FileText className="h-5 w-5" />
              <span>Session Details</span>
            </DialogTitle>
            <DialogDescription>
              {selectedSession && (
                <div className="space-y-2 mt-2">
                  <div>
                    <strong>Cashier:</strong> {selectedSession.user_profile?.full_name}
                  </div>
                  <div>
                    <strong>Started:</strong> {formatDateTime(selectedSession.start_time)}
                  </div>
                  {selectedSession.end_time && (
                    <div>
                      <strong>Ended:</strong> {formatDateTime(selectedSession.end_time)}
                    </div>
                  )}
                  <div>
                    <strong>Duration:</strong> {formatDuration(selectedSession.start_time, selectedSession.end_time)}
                  </div>
                  <div>
                    <strong>Total Revenue:</strong> <span className="text-success font-medium">{formatCurrency(selectedSession.total_revenue)}</span>
                  </div>
                </div>
              )}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Items Sold</h3>
            
            {loadingSales ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin" />
                <span className="ml-2">Loading sales...</span>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Product</TableHead>
                    <TableHead>Barcode</TableHead>
                    <TableHead>Quantity</TableHead>
                    <TableHead>Unit Price</TableHead>
                    <TableHead>Total</TableHead>
                    <TableHead>Time</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sessionSales.map((sale) => (
                    <TableRow key={sale.id}>
                      <TableCell className="font-medium">
                        {sale.product?.name || 'Unknown Product'}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {sale.product?.barcode}
                      </TableCell>
                      <TableCell className="text-center">
                        {sale.quantity}
                      </TableCell>
                      <TableCell>
                        {formatCurrency(parseFloat(sale.unit_price.toString()))}
                      </TableCell>
                      <TableCell className="font-medium">
                        {formatCurrency(parseFloat(sale.total_price.toString()))}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {new Date(sale.sale_time).toLocaleTimeString()}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}

            {!loadingSales && sessionSales.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                No items sold in this session
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default SalesReports;