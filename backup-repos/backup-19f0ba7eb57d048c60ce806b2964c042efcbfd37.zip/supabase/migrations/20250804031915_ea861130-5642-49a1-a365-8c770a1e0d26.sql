-- Add category field to products table
ALTER TABLE public.products 
ADD COLUMN category TEXT;

-- Update donomer98 to be an admin user
UPDATE public.profiles 
SET role = 'admin'
WHERE user_id IN (
  SELECT id FROM auth.users WHERE email = 'donomer98@example.com'
);