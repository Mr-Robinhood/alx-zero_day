import { useState } from "react";
import { 
  LayoutDashboard, 
  Package, 
  ShoppingCart, 
  LogOut,
  ChevronLeft,
  ChevronRight,
  CreditCard,
  Users,
  Settings,
} from "lucide-react";
import { NavLink, useLocation } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";

const menuItems = [
  { title: "Dashboard", url: "/", icon: LayoutDashboard, subItems: null },
  { title: "POS System", url: "/pos", icon: CreditCard, subItems: null },
  { title: "Products", url: "/products", icon: Package, subItems: null },
  {
    title: "Sales",
    icon: ShoppingCart,
    subItems: [
      { title: "Sales Report", url: "/sales" },
      { title: "Shift Report", url: "/shifts" },
    ],
  },
  {
    title: "Purchases",
    icon: Package,
    subItems: [
      { title: "New Purchase", url: "/purchases/new" },
      { title: "Purchase Report", url: "/purchases" },
      { title: "Companies", url: "/companies" },
      { title: "Payment", url: "/payments" },
    ],
  },
  { title: "User Management", url: "/users", icon: Users, adminOnly: false, subItems: null },
  { title: "Settings", url: "/settings", icon: Settings, subItems: null },
];

export function AppSidebar() {
  const { open, setOpen } = useSidebar();
  const { profile, signOut } = useAuth();
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(false);

  // Controlled open state for groups, initially open if current URL matches group path
  const [openGroups, setOpenGroups] = useState<{ [key: string]: boolean }>({
    Sales: location.pathname.startsWith("/sales") || 
           location.pathname.startsWith("/shifts"),
    Purchases: location.pathname.startsWith("/purchases") || 
               location.pathname.startsWith("/companies") || 
               location.pathname.startsWith("/payments"),
  });

  const toggleGroup = (title: string) => {
    setOpenGroups((prev) => ({
      ...prev,
      [title]: !prev[title],
    }));
  };

  const isActive = (path: string, isSubItem = false) => {
    if (isSubItem) {
      return location.pathname === path;
    }
    if (path === "/purchases" && location.pathname.startsWith("/purchases")) {
      return true;
    }
    if (path === "/") {
      return location.pathname === "/";
    }
    return location.pathname.startsWith(path);
  };

  const getNavCls = (path: string) =>
    isActive(path)
      ? "bg-primary text-primary-foreground font-medium"
      : "hover:bg-accent text-muted-foreground hover:text-foreground";

  const handleSignOut = async () => {
    await signOut();
  };

  return (
    <Sidebar className={`${collapsed ? "w-16" : "w-64"} transition-all duration-300 border-r bg-card`}>
      <SidebarContent className="flex flex-col h-full">
        {/* Header */}
        <div className="p-4 border-b">
          <div className="flex items-center justify-between">
            {!collapsed && (
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center">
                  <Package className="h-5 w-5 text-primary-foreground" />
                </div>
                <div>
                  <h2 className="font-semibold text-foreground">Pharmacy</h2>
                  <p className="text-xs text-muted-foreground">Management</p>
                </div>
              </div>
            )}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setCollapsed(!collapsed)}
              className="h-8 w-8 p-0"
            >
              {collapsed ? (
                <ChevronRight className="h-4 w-4" />
              ) : (
                <ChevronLeft className="h-4 w-4" />
              )}
            </Button>
          </div>
        </div>

        {/* Navigation */}
        <SidebarGroup className="flex-1">
          <SidebarGroupLabel className={collapsed ? "sr-only" : ""}>
            Navigation
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item: any) => {
                if (item.adminOnly && profile?.role !== "admin") {
                  return null;
                }

                if (item.subItems) {
                  const isOpen = openGroups[item.title] ?? false;
                  return (
                    <div key={item.title}>
                      <SidebarMenuItem>
                        <SidebarMenuButton
                          onClick={() => !collapsed && toggleGroup(item.title)}
                          className={`flex items-center justify-between px-3 py-2 cursor-pointer select-none w-full ${
                            (item.title === "Sales" && (location.pathname.startsWith("/sales") || location.pathname.startsWith("/shifts"))) ||
                            (item.title === "Purchases" && (location.pathname.startsWith("/purchases") || location.pathname.startsWith("/companies") || location.pathname.startsWith("/payments")))
                              ? "bg-primary text-primary-foreground font-medium" 
                              : "hover:bg-accent text-muted-foreground hover:text-foreground"
                          }`}
                        >
                          <div className="flex items-center space-x-3">
                            <item.icon className="h-5 w-5 flex-shrink-0" />
                            {!collapsed && <span className="font-medium">{item.title}</span>}
                          </div>
                          {!collapsed && (
                            <ChevronRight
                              className={`h-4 w-4 transition-transform duration-300 ${
                                isOpen ? "rotate-90" : ""
                              }`}
                            />
                          )}
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                      {!collapsed && isOpen && (
                        <div className="ml-6 space-y-1">
                          {item.subItems.map((subItem: any) => (
                            <SidebarMenuItem key={subItem.title}>
                              <SidebarMenuButton asChild>
                                <NavLink
                                  to={subItem.url}
                                  className={`flex items-center px-3 py-2 rounded-md transition-colors text-sm ${getNavCls(
                                    subItem.url
                                  )}`}
                                >
                                  <span className="font-medium">{subItem.title}</span>
                                </NavLink>
                              </SidebarMenuButton>
                            </SidebarMenuItem>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                }

                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild>
                      <NavLink
                        to={item.url}
                        className={`flex items-center space-x-3 px-3 py-2 rounded-md transition-colors ${getNavCls(
                          item.url
                        )}`}
                      >
                        <>
                          <item.icon className="h-5 w-5 flex-shrink-0" />
                          {!collapsed && <span className="font-medium">{item.title}</span>}
                        </>
                      </NavLink>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* User Profile & Logout */}
        <div className="p-4 border-t">
          {!collapsed && profile && (
            <div className="flex items-center space-x-3 mb-3 p-2 rounded-md bg-accent/50">
              <Avatar className="h-8 w-8">
                <AvatarFallback className="bg-primary text-primary-foreground">
                  {profile.full_name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")
                    .toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground truncate">{profile.full_name}</p>
                <p className="text-xs text-muted-foreground capitalize">{profile.role}</p>
              </div>
            </div>
          )}

          <Button
            variant="ghost"
            onClick={handleSignOut}
            className={`w-full justify-start text-muted-foreground hover:text-foreground hover:bg-accent ${
              collapsed ? "px-2" : "px-3"
            }`}
          >
            <LogOut className="h-5 w-5" />
            {!collapsed && <span className="ml-3">Sign Out</span>}
          </Button>
        </div>
      </SidebarContent>
    </Sidebar>
  );
}
