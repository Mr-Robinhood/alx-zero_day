import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Loader2, Plus, Clock, Eye, DollarSign, CreditCard, Banknote } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Layout } from '@/components/layout/Layout';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface Shift {
  id: string;
  cashier_name: string;
  start_time: string;
  end_time: string | null;
  cash_sales: number;
  card_sales: number;
  total_sales: number;
  status: 'active' | 'completed';
  created_at: string;
}

const ShiftReport = () => {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [shifts, setShifts] = useState<Shift[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [ending, setEnding] = useState<string | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedShift, setSelectedShift] = useState<Shift | null>(null);
  const [isDetailsDialogOpen, setIsDetailsDialogOpen] = useState(false);
  
  const [shiftForm, setShiftForm] = useState({
    cashier_name: '',
    cash_sales: '',
    card_sales: '',
  });

  useEffect(() => {
    fetchShifts();
  }, []);

  const fetchShifts = async () => {
    try {
      const { data, error } = await supabase
        .from('sessions')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching shifts:', error);
        // If sessions table doesn't exist, continue with empty array
        setShifts([]);
      } else {
        setShifts(data || []);
      }
    } catch (error) {
      console.error('Error fetching shifts:', error);
      toast({
        title: "Error",
        description: "Failed to load shift reports.",
        variant: "destructive",
      });
      setShifts([]);
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setShiftForm({
      cashier_name: '',
      cash_sales: '',
      card_sales: '',
    });
  };

  const handleStartShift = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreating(true);

    try {
      const cashSales = parseFloat(shiftForm.cash_sales) || 0;
      const cardSales = parseFloat(shiftForm.card_sales) || 0;
      
      const shiftData = {
        cashier_name: shiftForm.cashier_name,
        start_time: new Date().toISOString(),
        cash_sales: cashSales,
        card_sales: cardSales,
        total_sales: cashSales + cardSales,
        status: 'active' as const,
      };

      const { error } = await supabase
        .from('shifts')
        .insert([shiftData]);

      if (error) throw error;

      toast({
        title: "Shift started successfully",
        description: `Shift for ${shiftForm.cashier_name} has been started.`,
      });

      resetForm();
      setIsDialogOpen(false);
      fetchShifts();
    } catch (error: any) {
      console.error('Error starting shift:', error);
      toast({
        title: "Failed to start shift",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setCreating(false);
    }
  };

  const handleEndShift = async (shiftId: string) => {
    setEnding(shiftId);

    try {
      const { error } = await supabase
        .from('shifts')
        .update({
          end_time: new Date().toISOString(),
          status: 'completed'
        })
        .eq('id', shiftId);

      if (error) throw error;

      toast({
        title: "Shift ended successfully",
        description: "The shift has been completed.",
      });

      fetchShifts();
    } catch (error: any) {
      console.error('Error ending shift:', error);
      toast({
        title: "Failed to end shift",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setEnding(null);
    }
  };

  const openDetailsDialog = (shift: Shift) => {
    setSelectedShift(shift);
    setIsDetailsDialogOpen(true);
  };

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  const formatDuration = (startTime: string, endTime: string | null) => {
    if (!endTime) return 'Ongoing';
    
    const start = new Date(startTime);
    const end = new Date(endTime);
    const diffMs = end.getTime() - start.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    
    return `${diffHours}h ${diffMinutes}m`;
  };

  // Calculate stats
  const activeShifts = shifts.filter(s => s.status === 'active').length;
  const todayShifts = shifts.filter(s => 
    new Date(s.start_time).toDateString() === new Date().toDateString()
  );
  const todayRevenue = todayShifts.reduce((sum, shift) => sum + shift.total_sales, 0);
  const todayCashSales = todayShifts.reduce((sum, shift) => sum + shift.cash_sales, 0);
  const todayCardSales = todayShifts.reduce((sum, shift) => sum + shift.card_sales, 0);

  if (loading) {
    return (
      <Layout>
        <div className="space-y-6 animate-pulse">
          <div className="h-8 bg-muted rounded w-1/4"></div>
          <div className="h-96 bg-muted rounded-lg"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6 animate-fade-in">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground flex items-center space-x-3">
              <Clock className="h-8 w-8 text-primary" />
              <span>Shift Reports</span>
            </h1>
            <p className="text-muted-foreground mt-1">
              View completed shift reports and working hours history
            </p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid gap-6 md:grid-cols-4">
          <Card className="medical-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Active Shifts
              </CardTitle>
              <Clock className="h-5 w-5 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">
                {activeShifts}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Currently working
              </p>
            </CardContent>
          </Card>

          <Card className="medical-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Today's Revenue
              </CardTitle>
              <DollarSign className="h-5 w-5 text-success" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-success">
                ${todayRevenue.toFixed(2)}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Total sales today
              </p>
            </CardContent>
          </Card>

          <Card className="medical-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Cash Sales
              </CardTitle>
              <Banknote className="h-5 w-5 text-warning" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-warning">
                ${todayCashSales.toFixed(2)}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Cash payments today
              </p>
            </CardContent>
          </Card>

          <Card className="medical-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Card Sales
              </CardTitle>
              <CreditCard className="h-5 w-5 text-info" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-info">
                ${todayCardSales.toFixed(2)}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Card payments today
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Shifts Table */}
        <Card className="medical-card">
          <CardHeader>
            <CardTitle>All Shifts</CardTitle>
            <CardDescription>
              Complete history of cashier shifts and sales
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Cashier</TableHead>
                  <TableHead>Start Time</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead>Cash Sales</TableHead>
                  <TableHead>Card Sales</TableHead>
                  <TableHead>Total Sales</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {shifts.map((shift) => (
                  <TableRow key={shift.id}>
                    <TableCell className="font-medium">
                      {shift.cashier_name}
                    </TableCell>
                    <TableCell>
                      {formatDateTime(shift.start_time)}
                    </TableCell>
                    <TableCell>
                      {formatDuration(shift.start_time, shift.end_time)}
                    </TableCell>
                    <TableCell>
                      ${shift.cash_sales.toFixed(2)}
                    </TableCell>
                    <TableCell>
                      ${shift.card_sales.toFixed(2)}
                    </TableCell>
                    <TableCell className="font-medium">
                      ${shift.total_sales.toFixed(2)}
                    </TableCell>
                    <TableCell>
                      {shift.status === 'active' ? (
                        <Badge className="status-active">
                          Active
                        </Badge>
                      ) : (
                        <Badge className="bg-muted text-muted-foreground">
                          Completed
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openDetailsDialog(shift)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        {shift.status === 'active' && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEndShift(shift.id)}
                            disabled={ending === shift.id}
                          >
                            {ending === shift.id ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              'End Shift'
                            )}
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Shift Details Dialog */}
        <Dialog open={isDetailsDialogOpen} onOpenChange={setIsDetailsDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-2">
                <Clock className="h-5 w-5" />
                <span>Shift Details</span>
              </DialogTitle>
            </DialogHeader>
            {selectedShift && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Cashier</Label>
                    <p className="font-medium">{selectedShift.cashier_name}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Status</Label>
                    <Badge className={selectedShift.status === 'active' ? 'status-active' : 'bg-muted text-muted-foreground'}>
                      {selectedShift.status === 'active' ? 'Active' : 'Completed'}
                    </Badge>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Start Time</Label>
                    <p className="font-medium">{formatDateTime(selectedShift.start_time)}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">End Time</Label>
                    <p className="font-medium">
                      {selectedShift.end_time ? formatDateTime(selectedShift.end_time) : 'Ongoing'}
                    </p>
                  </div>
                </div>
                
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Duration</Label>
                  <p className="font-medium">{formatDuration(selectedShift.start_time, selectedShift.end_time)}</p>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Cash Sales</Label>
                    <p className="font-medium text-warning">${selectedShift.cash_sales.toFixed(2)}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Card Sales</Label>
                    <p className="font-medium text-info">${selectedShift.card_sales.toFixed(2)}</p>
                  </div>
                </div>
                
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Total Sales</Label>
                  <p className="text-2xl font-bold text-success">${selectedShift.total_sales.toFixed(2)}</p>
                </div>
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDetailsDialogOpen(false)}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
};

export default ShiftReport;