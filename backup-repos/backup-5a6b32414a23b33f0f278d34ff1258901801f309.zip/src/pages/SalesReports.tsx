import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Loader2, FileText, Calendar, DollarSign, Eye, ArrowLeft } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Navigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';

interface Shift {
  id: string;
  user_id: string;
  start_time: string;
  end_time: string | null;
  status: string;
  created_at: string;
  user_profile?: {
    full_name: string;
  };
}

interface Sale {
  id: string;
  session_id: string;
  product_id: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  sale_time: string;
  product?: {
    name: string;
    barcode: string;
  };
}

interface ShiftWithRevenue extends Shift {
  total_revenue: number;
  items_count: number;
}

const SalesReports = () => {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [shifts, setShifts] = useState<ShiftWithRevenue[]>([]);
  const [selectedShift, setSelectedShift] = useState<ShiftWithRevenue | null>(null);
  const [shiftSales, setShiftSales] = useState<Sale[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingSales, setLoadingSales] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Only admins can access this page
  if (profile?.role !== 'admin') {
    return <Navigate to="/" replace />;
  }

  useEffect(() => {
    fetchShifts();
  }, []);

  const fetchShifts = async () => {
    try {
      // First get all sessions
      const { data: shiftsData, error: shiftsError } = await supabase
        .from('sessions')
        .select('*')
        .order('start_time', { ascending: false });

      if (shiftsError) throw shiftsError;

      // Then get sales data and user profiles for each shift
      const shiftsWithRevenue: ShiftWithRevenue[] = [];
      
      for (const shift of shiftsData || []) {
        // Get sales data for this shift
        const { data: salesData, error: salesError } = await supabase
          .from('sales')
          .select('total_price')
          .eq('session_id', shift.id);

        if (salesError) {
          console.error('Error fetching sales for shift:', shift.id, salesError);
          continue;
        }

        // Get user profile for this shift
        const { data: profileData, error: profileError } = await supabase
          .from('profiles')
          .select('full_name')
          .eq('user_id', shift.user_id)
          .single();

        if (profileError) {
          console.error('Error fetching profile for shift:', shift.id, profileError);
        }

        const totalRevenue = salesData?.reduce((sum, sale) => sum + parseFloat(sale.total_price.toString()), 0) || 0;
        const itemsCount = salesData?.length || 0;

        shiftsWithRevenue.push({
          ...shift,
          user_profile: profileData || undefined,
          total_revenue: totalRevenue,
          items_count: itemsCount,
        });
      }

      setShifts(shiftsWithRevenue);
    } catch (error) {
      console.error('Error fetching shifts:', error);
      toast({
        title: "Error",
        description: "Failed to load shift reports.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchShiftSales = async (shiftId: string) => {
    setLoadingSales(true);
    try {
      const { data, error } = await supabase
        .from('sales')
        .select(`
          *,
          products(name, barcode)
        `)
        .eq('session_id', shiftId)
        .order('sale_time', { ascending: false });

      if (error) throw error;
      setShiftSales(data || []);
    } catch (error) {
      console.error('Error fetching shift sales:', error);
      toast({
        title: "Error",
        description: "Failed to load shift sales.",
        variant: "destructive",
      });
    } finally {
      setLoadingSales(false);
    }
  };

  const handleViewShift = (shift: ShiftWithRevenue) => {
    setSelectedShift(shift);
    setIsDialogOpen(true);
    fetchShiftSales(shift.id);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  const formatDuration = (startTime: string, endTime: string | null) => {
    if (!endTime) return 'Ongoing';
    
    const start = new Date(startTime);
    const end = new Date(endTime);
    const diffMs = end.getTime() - start.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    
    if (diffHours > 0) {
      return `${diffHours}h ${diffMinutes}m`;
    }
    return `${diffMinutes}m`;
  };

  if (loading) {
    return (
      <Layout>
        <div className="space-y-6 animate-pulse">
          <div className="h-8 bg-muted rounded w-1/4"></div>
          <div className="h-96 bg-muted rounded-lg"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center space-x-3">
            <FileText className="h-8 w-8 text-primary" />
            <span>Shift Reports</span>
          </h1>
          <p className="text-muted-foreground mt-1">
            View detailed shift reports and transaction history
          </p>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid gap-6 md:grid-cols-3">
        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Shifts
            </CardTitle>
            <Calendar className="h-5 w-5 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">
              {shifts.length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              All time shifts
            </p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Revenue
            </CardTitle>
            <DollarSign className="h-5 w-5 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-success">
              {formatCurrency(shifts.reduce((sum, shift) => sum + shift.total_revenue, 0))}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              All time sales
            </p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Active Shifts
            </CardTitle>
            <Calendar className="h-5 w-5 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-warning">
              {shifts.filter(s => s.status === 'active').length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Currently ongoing
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Sessions Table */}
      <Card className="medical-card">
        <CardHeader>
          <CardTitle>Work Shifts</CardTitle>
          <CardDescription>
            All pharmacist shifts with revenue and duration information
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date & Time</TableHead>
                <TableHead>Pharmacist</TableHead>
                <TableHead>Duration</TableHead>
                <TableHead>Items Sold</TableHead>
                <TableHead>Revenue</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {shifts.map((shift) => (
                <TableRow key={shift.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">
                        {new Date(shift.start_time).toLocaleDateString()}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {new Date(shift.start_time).toLocaleTimeString()}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="font-medium">
                    {shift.user_profile?.full_name || 'Unknown'}
                  </TableCell>
                  <TableCell>
                    {formatDuration(shift.start_time, shift.end_time)}
                  </TableCell>
                  <TableCell className="text-center">
                    {shift.items_count}
                  </TableCell>
                  <TableCell className="font-medium text-success">
                    {formatCurrency(shift.total_revenue)}
                  </TableCell>
                  <TableCell>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      shift.status === 'active' 
                        ? 'bg-warning/20 text-warning' 
                        : 'bg-success/20 text-success'
                    }`}>
                      {shift.status}
                    </span>
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleViewShift(shift)}
                      className="h-8 w-8 p-0"
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Shift Details Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <FileText className="h-5 w-5" />
              <span>Shift Details</span>
            </DialogTitle>
            <DialogDescription>
              {selectedShift && (
                <div className="space-y-2 mt-2">
                  <div>
                    <strong>Pharmacist:</strong> {selectedShift.user_profile?.full_name}
                  </div>
                  <div>
                    <strong>Started:</strong> {formatDateTime(selectedShift.start_time)}
                  </div>
                  {selectedShift.end_time && (
                    <div>
                      <strong>Ended:</strong> {formatDateTime(selectedShift.end_time)}
                    </div>
                  )}
                  <div>
                    <strong>Duration:</strong> {formatDuration(selectedShift.start_time, selectedShift.end_time)}
                  </div>
                  <div>
                    <strong>Total Revenue:</strong> <span className="text-success font-medium">{formatCurrency(selectedShift.total_revenue)}</span>
                  </div>
                </div>
              )}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Items Sold</h3>
            
            {loadingSales ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin" />
                <span className="ml-2">Loading sales...</span>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Product</TableHead>
                    <TableHead>Barcode</TableHead>
                    <TableHead>Quantity</TableHead>
                    <TableHead>Unit Price</TableHead>
                    <TableHead>Total</TableHead>
                    <TableHead>Time</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {shiftSales.map((sale) => (
                    <TableRow key={sale.id}>
                      <TableCell className="font-medium">
                        {sale.product?.name || 'Unknown Product'}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {sale.product?.barcode}
                      </TableCell>
                      <TableCell className="text-center">
                        {sale.quantity}
                      </TableCell>
                      <TableCell>
                        {formatCurrency(parseFloat(sale.unit_price.toString()))}
                      </TableCell>
                      <TableCell className="font-medium">
                        {formatCurrency(parseFloat(sale.total_price.toString()))}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {new Date(sale.sale_time).toLocaleTimeString()}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}

            {!loadingSales && shiftSales.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                No items sold in this shift
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
      </div>
    </Layout>
  );
};

export default SalesReports;