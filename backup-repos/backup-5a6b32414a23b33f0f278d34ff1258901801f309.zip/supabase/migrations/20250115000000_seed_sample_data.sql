-- Sample Data Migration for Pharmacy Management System
-- This migration adds comprehensive sample data for testing and demonstration

-- Insert sample companies/suppliers
INSERT INTO public.companies (id, name, contact_person, email, phone, address, outstanding_bill) VALUES
('550e8400-e29b-41d4-a716-446655440001', 'MediSupply Corp', 'Sarah Johnson', 'sarah@medisupply.com', '+1-555-0101', '123 Medical Plaza, Healthcare City, HC 12345', 2500.00),
('550e8400-e29b-41d4-a716-446655440002', 'PharmaCorp International', 'Michael Chen', 'michael@pharmacorp.com', '+1-555-0102', '456 Pharma Street, Medicine Town, MT 67890', 1800.75),
('550e8400-e29b-41d4-a716-446655440003', 'Global Health Distributors', 'Emma Rodriguez', 'emma@globalhealthdist.com', '+1-555-0103', '789 Distribution Ave, Supply City, SC 11111', 3200.50),
('550e8400-e29b-41d4-a716-446655440004', 'BioMed Solutions', 'David Wilson', 'david@biomedsolutions.com', '+1-555-0104', '321 Innovation Blvd, Research Park, RP 22222', 950.25),
('550e8400-e29b-41d4-a716-446655440005', 'HealthCare Supplies Ltd', 'Lisa Thompson', 'lisa@healthcaresupplies.com', '+1-555-0105', '654 Wellness Way, Care Center, CC 33333', 1650.00);

-- Insert sample products with various categories
INSERT INTO public.products (id, name, barcode, price, quantity, low_stock_threshold, expiration_date, description, category) VALUES
-- Pain Relief & Fever
('660e8400-e29b-41d4-a716-446655440001', 'Paracetamol 500mg', '1234567890123', 2.50, 150, 20, '2025-12-31', 'Effective pain relief and fever reducer', 'Pain Relief'),
('660e8400-e29b-41d4-a716-446655440002', 'Ibuprofen 400mg', '1234567890124', 3.75, 120, 15, '2025-11-30', 'Anti-inflammatory pain reliever', 'Pain Relief'),
('660e8400-e29b-41d4-a716-446655440003', 'Aspirin 325mg', '1234567890125', 1.99, 200, 25, '2026-01-15', 'Pain relief and blood thinner', 'Pain Relief'),
('660e8400-e29b-41d4-a716-446655440004', 'Acetaminophen Extra Strength', '1234567890126', 4.25, 80, 10, '2025-10-20', 'Extra strength pain and fever relief', 'Pain Relief'),

-- Cold & Flu
('660e8400-e29b-41d4-a716-446655440005', 'Cough Syrup 200ml', '1234567890127', 8.50, 60, 8, '2025-09-15', 'Effective cough suppressant', 'Cold & Flu'),
('660e8400-e29b-41d4-a716-446655440006', 'Throat Lozenges', '1234567890128', 3.99, 90, 12, '2026-03-10', 'Soothing throat relief', 'Cold & Flu'),
('660e8400-e29b-41d4-a716-446655440007', 'Decongestant Tablets', '1234567890129', 6.75, 45, 8, '2025-08-25', 'Nasal congestion relief', 'Cold & Flu'),
('660e8400-e29b-41d4-a716-446655440008', 'Flu Relief Capsules', '1234567890130', 9.99, 35, 5, '2025-07-30', 'Multi-symptom flu relief', 'Cold & Flu'),

-- Digestive Health
('660e8400-e29b-41d4-a716-446655440009', 'Antacid Tablets', '1234567890131', 4.50, 100, 15, '2026-02-28', 'Fast-acting heartburn relief', 'Digestive'),
('660e8400-e29b-41d4-a716-446655440010', 'Probiotics 30 caps', '1234567890132', 15.99, 25, 5, '2025-06-15', 'Digestive health support', 'Digestive'),
('660e8400-e29b-41d4-a716-446655440011', 'Anti-Diarrheal', '1234567890133', 7.25, 40, 8, '2025-12-10', 'Diarrhea relief medication', 'Digestive'),
('660e8400-e29b-41d4-a716-446655440012', 'Fiber Supplement', '1234567890134', 12.50, 30, 5, '2026-04-20', 'Daily fiber supplement', 'Digestive'),

-- Vitamins & Supplements
('660e8400-e29b-41d4-a716-446655440013', 'Vitamin C 1000mg', '1234567890135', 8.99, 75, 10, '2026-08-15', 'Immune system support', 'Vitamins'),
('660e8400-e29b-41d4-a716-446655440014', 'Multivitamin Daily', '1234567890136', 13.75, 50, 8, '2026-05-30', 'Complete daily nutrition', 'Vitamins'),
('660e8400-e29b-41d4-a716-446655440015', 'Vitamin D3 2000IU', '1234567890137', 9.50, 65, 10, '2026-07-25', 'Bone and immune health', 'Vitamins'),
('660e8400-e29b-41d4-a716-446655440016', 'Omega-3 Fish Oil', '1234567890138', 16.99, 40, 6, '2025-11-10', 'Heart and brain health', 'Vitamins'),

-- Skin Care
('660e8400-e29b-41d4-a716-446655440017', 'Hydrocortisone Cream', '1234567890139', 5.75, 55, 8, '2025-09-30', 'Anti-itch skin relief', 'Skin Care'),
('660e8400-e29b-41d4-a716-446655440018', 'Antibiotic Ointment', '1234567890140', 6.25, 70, 10, '2025-10-15', 'Wound care and infection prevention', 'Skin Care'),
('660e8400-e29b-41d4-a716-446655440019', 'Sunscreen SPF 50', '1234567890141', 11.99, 45, 8, '2026-06-30', 'Broad spectrum sun protection', 'Skin Care'),
('660e8400-e29b-41d4-a716-446655440020', 'Moisturizing Lotion', '1234567890142', 7.50, 60, 10, '2026-03-20', 'Daily skin moisturizer', 'Skin Care'),

-- Allergy & Respiratory
('660e8400-e29b-41d4-a716-446655440021', 'Antihistamine 24hr', '1234567890143', 8.25, 85, 12, '2025-12-05', '24-hour allergy relief', 'Allergy'),
('660e8400-e29b-41d4-a716-446655440022', 'Nasal Spray', '1234567890144', 9.75, 35, 6, '2025-08-10', 'Allergy nasal congestion relief', 'Allergy'),
('660e8400-e29b-41d4-a716-446655440023', 'Eye Drops Allergy', '1234567890145', 6.99, 50, 8, '2025-11-25', 'Itchy, watery eye relief', 'Allergy'),
('660e8400-e29b-41d4-a716-446655440024', 'Inhaler (OTC)', '1234567890146', 12.75, 20, 3, '2025-07-15', 'Bronchial breathing support', 'Respiratory'),

-- First Aid & Medical Supplies
('660e8400-e29b-41d4-a716-446655440025', 'Bandages Assorted', '1234567890147', 4.99, 100, 15, '2027-01-01', 'Various sizes adhesive bandages', 'First Aid'),
('660e8400-e29b-41d4-a716-446655440026', 'Thermometer Digital', '1234567890148', 15.50, 25, 5, '2027-12-31', 'Fast, accurate temperature reading', 'Medical Devices'),
('660e8400-e29b-41d4-a716-446655440027', 'Blood Pressure Monitor', '1234567890149', 45.99, 12, 2, '2027-06-30', 'Home blood pressure monitoring', 'Medical Devices'),
('660e8400-e29b-41d4-a716-446655440028', 'Glucose Test Strips', '1234567890150', 25.75, 30, 5, '2025-12-31', 'Blood glucose monitoring strips', 'Diabetic Care');

-- Create some sample user sessions (we'll use placeholder user IDs that would be created by auth)
-- Note: In real scenario, these would be actual auth.users IDs
-- For demo purposes, we'll create sessions that could be linked to real users later

-- Insert sample purchases (linking products to companies)
INSERT INTO public.purchases (id, company_id, product_id, quantity, unit_cost, total_cost, invoice_number, user_id) VALUES
-- Purchases from MediSupply Corp
('770e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440001', '660e8400-e29b-41d4-a716-446655440001', 200, 1.25, 250.00, 'INV-2024-001', '00000000-0000-0000-0000-000000000000'),
('770e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440001', '660e8400-e29b-41d4-a716-446655440002', 150, 2.00, 300.00, 'INV-2024-001', '00000000-0000-0000-0000-000000000000'),
('770e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440001', '660e8400-e29b-41d4-a716-446655440005', 80, 4.50, 360.00, 'INV-2024-002', '00000000-0000-0000-0000-000000000000'),

-- Purchases from PharmaCorp International
('770e8400-e29b-41d4-a716-446655440004', '550e8400-e29b-41d4-a716-446655440002', '660e8400-e29b-41d4-a716-446655440013', 100, 4.50, 450.00, 'PC-2024-101', '00000000-0000-0000-0000-000000000000'),
('770e8400-e29b-41d4-a716-446655440005', '550e8400-e29b-41d4-a716-446655440002', '660e8400-e29b-41d4-a716-446655440014', 75, 7.00, 525.00, 'PC-2024-101', '00000000-0000-0000-0000-000000000000'),
('770e8400-e29b-41d4-a716-446655440006', '550e8400-e29b-41d4-a716-446655440002', '660e8400-e29b-41d4-a716-446655440016', 60, 8.50, 510.00, 'PC-2024-102', '00000000-0000-0000-0000-000000000000'),

-- Purchases from Global Health Distributors
('770e8400-e29b-41d4-a716-446655440007', '550e8400-e29b-41d4-a716-446655440003', '660e8400-e29b-41d4-a716-446655440025', 150, 2.50, 375.00, 'GHD-2024-501', '00000000-0000-0000-0000-000000000000'),
('770e8400-e29b-41d4-a716-446655440008', '550e8400-e29b-41d4-a716-446655440003', '660e8400-e29b-41d4-a716-446655440026', 40, 8.00, 320.00, 'GHD-2024-501', '00000000-0000-0000-0000-000000000000'),
('770e8400-e29b-41d4-a716-446655440009', '550e8400-e29b-41d4-a716-446655440003', '660e8400-e29b-41d4-a716-446655440027', 20, 25.00, 500.00, 'GHD-2024-502', '00000000-0000-0000-0000-000000000000'),

-- Purchases from BioMed Solutions
('770e8400-e29b-41d4-a716-446655440010', '550e8400-e29b-41d4-a716-446655440004', '660e8400-e29b-41d4-a716-446655440010', 50, 8.00, 400.00, 'BMS-2024-201', '00000000-0000-0000-0000-000000000000'),
('770e8400-e29b-41d4-a716-446655440011', '550e8400-e29b-41d4-a716-446655440004', '660e8400-e29b-41d4-a716-446655440028', 40, 12.50, 500.00, 'BMS-2024-201', '00000000-0000-0000-0000-000000000000'),

-- Purchases from HealthCare Supplies Ltd
('770e8400-e29b-41d4-a716-446655440012', '550e8400-e29b-41d4-a716-446655440005', '660e8400-e29b-41d4-a716-446655440017', 80, 3.00, 240.00, 'HCS-2024-301', '00000000-0000-0000-0000-000000000000'),
('770e8400-e29b-41d4-a716-446655440013', '550e8400-e29b-41d4-a716-446655440005', '660e8400-e29b-41d4-a716-446655440018', 100, 3.25, 325.00, 'HCS-2024-301', '00000000-0000-0000-0000-000000000000'),
('770e8400-e29b-41d4-a716-446655440014', '550e8400-e29b-41d4-a716-446655440005', '660e8400-e29b-41d4-a716-446655440019', 60, 6.00, 360.00, 'HCS-2024-302', '00000000-0000-0000-0000-000000000000');

-- Insert sample payments (partial payments to companies)
INSERT INTO public.payments (id, company_id, amount, note, user_id) VALUES
('880e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440001', 500.00, 'Partial payment for January invoices', '00000000-0000-0000-0000-000000000000'),
('880e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440002', 300.00, 'Payment for PC-2024-101', '00000000-0000-0000-0000-000000000000'),
('880e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440003', 1000.00, 'Monthly payment installment', '00000000-0000-0000-0000-000000000000'),
('880e8400-e29b-41d4-a716-446655440004', '550e8400-e29b-41d4-a716-446655440004', 450.00, 'Full payment for BMS-2024-201', '00000000-0000-0000-0000-000000000000'),
('880e8400-e29b-41d4-a716-446655440005', '550e8400-e29b-41d4-a716-446655440005', 275.00, 'Partial payment for skin care products', '00000000-0000-0000-0000-000000000000');

-- Note: Sales data will be generated when actual users start using the POS system
-- as it requires real user sessions and authentication

-- Create some sample low-stock scenarios for testing alerts
UPDATE public.products SET quantity = 5 WHERE id = '660e8400-e29b-41d4-a716-446655440024'; -- Inhaler (low stock)
UPDATE public.products SET quantity = 8 WHERE id = '660e8400-e29b-41d4-a716-446655440007'; -- Decongestant (low stock)
UPDATE public.products SET quantity = 3 WHERE id = '660e8400-e29b-41d4-a716-446655440010'; -- Probiotics (very low stock)

-- Add some products that are near expiration for testing
UPDATE public.products SET expiration_date = '2025-02-28' WHERE id = '660e8400-e29b-41d4-a716-446655440008'; -- Flu Relief (expiring soon)
UPDATE public.products SET expiration_date = '2025-03-15' WHERE id = '660e8400-e29b-41d4-a716-446655440022'; -- Nasal Spray (expiring soon)

-- Create indexes for better performance on sample data
CREATE INDEX IF NOT EXISTS idx_products_category ON public.products(category);
CREATE INDEX IF NOT EXISTS idx_products_expiration ON public.products(expiration_date);
CREATE INDEX IF NOT EXISTS idx_purchases_invoice ON public.purchases(invoice_number);
CREATE INDEX IF NOT EXISTS idx_companies_name ON public.companies(name);

-- Add some helpful views for reporting
CREATE OR REPLACE VIEW public.low_stock_products AS
SELECT 
  id,
  name,
  quantity,
  low_stock_threshold,
  category,
  price,
  (quantity::float / low_stock_threshold::float * 100) as stock_percentage
FROM public.products 
WHERE quantity <= low_stock_threshold
ORDER BY stock_percentage ASC;

CREATE OR REPLACE VIEW public.expiring_products AS
SELECT 
  id,
  name,
  expiration_date,
  quantity,
  category,
  price,
  (expiration_date - CURRENT_DATE) as days_until_expiry
FROM public.products 
WHERE expiration_date <= CURRENT_DATE + INTERVAL '90 days'
  AND expiration_date > CURRENT_DATE
ORDER BY expiration_date ASC;

CREATE OR REPLACE VIEW public.company_balances AS
SELECT 
  c.id,
  c.name,
  c.contact_person,
  c.email,
  c.phone,
  c.outstanding_bill,
  COALESCE(SUM(pu.total_cost), 0) as total_purchases,
  COALESCE(SUM(pa.amount), 0) as total_payments,
  c.outstanding_bill as current_balance
FROM public.companies c
LEFT JOIN public.purchases pu ON c.id = pu.company_id
LEFT JOIN public.payments pa ON c.id = pa.company_id
GROUP BY c.id, c.name, c.contact_person, c.email, c.phone, c.outstanding_bill
ORDER BY c.outstanding_bill DESC;

-- Grant necessary permissions for the views
GRANT SELECT ON public.low_stock_products TO authenticated;
GRANT SELECT ON public.expiring_products TO authenticated;
GRANT SELECT ON public.company_balances TO authenticated;

-- Add RLS policies for the views
CREATE POLICY "All authenticated users can view low stock products" ON public.low_stock_products FOR SELECT USING (true);
CREATE POLICY "All authenticated users can view expiring products" ON public.expiring_products FOR SELECT USING (true);
CREATE POLICY "All authenticated users can view company balances" ON public.company_balances FOR SELECT USING (true);

-- Insert a comment to track this migration
COMMENT ON SCHEMA public IS 'Sample data migration completed - includes companies, products, purchases, and payments for testing';