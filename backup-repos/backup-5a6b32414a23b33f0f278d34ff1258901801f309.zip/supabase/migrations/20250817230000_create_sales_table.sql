CREATE TABLE IF NOT EXISTS sales (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID NOT NULL REFERENCES sessions(id),
    user_id UUID NOT NULL REFERENCES auth.users(id),
    total_amount REAL NOT NULL,
    payment_method TEXT,
    amount_paid REAL,
    change_due REAL,
    created_at TIMESTAMPTZ DEFAULT now()
);
