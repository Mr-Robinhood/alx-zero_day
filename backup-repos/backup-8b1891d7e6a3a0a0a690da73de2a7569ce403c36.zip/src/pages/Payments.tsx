import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Plus, CreditCard, DollarSign } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Textarea } from '@/components/ui/textarea';

interface Payment {
  id: string;
  company_id: string;
  amount: number;
  note: string | null;
  created_at: string;
  companies: { name: string };
}

interface Company {
  id: string;
  name: string;
  outstanding_bill: number;
}

const Payments = () => {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [payments, setPayments] = useState<Payment[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  const [paymentForm, setPaymentForm] = useState({
    company_id: '',
    amount: '',
    note: '',
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // Fetch payments with company names
      const { data: paymentsData, error: paymentsError } = await supabase
        .from('payments')
        .select(`
          *,
          companies(name)
        `)
        .order('created_at', { ascending: false });

      if (paymentsError) throw paymentsError;

      // Fetch companies with outstanding bills
      const { data: companiesData, error: companiesError } = await supabase
        .from('companies')
        .select('id, name, outstanding_bill')
        .order('name');

      if (companiesError) throw companiesError;

      setPayments(paymentsData || []);
      setCompanies(companiesData || []);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast({
        title: "Error",
        description: "Failed to load data.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setPaymentForm({
      company_id: '',
      amount: '',
      note: '',
    });
  };

  const handleCreatePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreating(true);

    try {
      const selectedCompany = companies.find(c => c.id === paymentForm.company_id);
      const paymentAmount = parseFloat(paymentForm.amount);

      if (selectedCompany && paymentAmount > selectedCompany.outstanding_bill) {
        toast({
          title: "Payment amount too high",
          description: `Payment amount cannot exceed outstanding bill of $${selectedCompany.outstanding_bill.toFixed(2)}`,
          variant: "destructive",
        });
        return;
      }

      const { error } = await supabase
        .from('payments')
        .insert([{
          company_id: paymentForm.company_id,
          amount: paymentAmount,
          note: paymentForm.note || null,
          user_id: profile?.user_id,
        }]);

      if (error) throw error;

      toast({
        title: "Payment recorded successfully",
        description: "Company bill has been updated.",
      });

      resetForm();
      setIsDialogOpen(false);
      fetchData();
    } catch (error: any) {
      console.error('Error creating payment:', error);
      toast({
        title: "Failed to record payment",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setCreating(false);
    }
  };

  const openCreateDialog = () => {
    resetForm();
    setIsDialogOpen(true);
  };

  const selectedCompany = companies.find(c => c.id === paymentForm.company_id);

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-8 bg-muted rounded w-1/4"></div>
        <div className="h-96 bg-muted rounded-lg"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center space-x-3">
            <CreditCard className="h-8 w-8 text-primary" />
            <span>Payments</span>
          </h1>
          <p className="text-muted-foreground mt-1">
            Record payments to reduce company bills
          </p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="medical-gradient" onClick={openCreateDialog}>
              <Plus className="h-4 w-4 mr-2" />
              Record Payment
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-2">
                <CreditCard className="h-5 w-5" />
                <span>Record New Payment</span>
              </DialogTitle>
              <DialogDescription>
                Record a payment to reduce a company's outstanding bill
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreatePayment} className="space-y-4">
              {/* Company Selection */}
              <div className="space-y-2">
                <Label htmlFor="company">Company</Label>
                <Select value={paymentForm.company_id} onValueChange={(value) => setPaymentForm({ ...paymentForm, company_id: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a company" />
                  </SelectTrigger>
                  <SelectContent>
                    {companies.filter(c => Number(c.outstanding_bill) > 0).map((company) => (
                      <SelectItem key={company.id} value={company.id}>
                        {company.name} (${Number(company.outstanding_bill).toFixed(2)} owed)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Outstanding Bill Display */}
              {selectedCompany && (
                <div className="p-3 bg-accent rounded-lg">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Outstanding Bill:</span>
                    <span className="text-lg font-bold text-destructive">
                      ${Number(selectedCompany.outstanding_bill).toFixed(2)}
                    </span>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="amount">Payment Amount ($)</Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  placeholder="100.00"
                  value={paymentForm.amount}
                  onChange={(e) => setPaymentForm({ ...paymentForm, amount: e.target.value })}
                  required
                  max={selectedCompany ? selectedCompany.outstanding_bill : undefined}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="note">Note (Optional)</Label>
                <Textarea
                  id="note"
                  placeholder="Payment method, reference number, etc..."
                  value={paymentForm.note}
                  onChange={(e) => setPaymentForm({ ...paymentForm, note: e.target.value })}
                />
              </div>

              {/* Remaining Bill Preview */}
              {selectedCompany && paymentForm.amount && (
                <div className="p-3 bg-success/10 rounded-lg">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Remaining Bill:</span>
                    <span className="text-lg font-bold text-success">
                      ${Math.max(0, Number(selectedCompany.outstanding_bill) - parseFloat(paymentForm.amount || '0')).toFixed(2)}
                    </span>
                  </div>
                </div>
              )}

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  className="medical-gradient" 
                  disabled={creating || !paymentForm.company_id || !paymentForm.amount}
                >
                  {creating ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Recording...
                    </>
                  ) : (
                    'Record Payment'
                  )}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid gap-6 md:grid-cols-3">
        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Payments
            </CardTitle>
            <CreditCard className="h-5 w-5 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">
              {payments.length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Payment records
            </p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Paid
            </CardTitle>
            <DollarSign className="h-5 w-5 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-success">
              ${payments.reduce((total, payment) => total + Number(payment.amount), 0).toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              All payments made
            </p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              This Month
            </CardTitle>
            <CreditCard className="h-5 w-5 text-info" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-info">
              ${payments.filter(p => {
                const paymentDate = new Date(p.created_at);
                const currentDate = new Date();
                return paymentDate.getMonth() === currentDate.getMonth() && 
                       paymentDate.getFullYear() === currentDate.getFullYear();
              }).reduce((total, payment) => total + Number(payment.amount), 0).toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Payments this month
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Companies with Outstanding Bills */}
      <Card className="medical-card">
        <CardHeader>
          <CardTitle>Companies with Outstanding Bills</CardTitle>
          <CardDescription>
            Companies that have pending payments
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Company</TableHead>
                <TableHead>Outstanding Bill</TableHead>
                <TableHead>Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {companies.filter(c => Number(c.outstanding_bill) > 0).map((company) => (
                <TableRow key={company.id}>
                  <TableCell className="font-medium">{company.name}</TableCell>
                  <TableCell className="text-destructive font-medium">
                    ${Number(company.outstanding_bill).toFixed(2)}
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setPaymentForm({ ...paymentForm, company_id: company.id });
                        setIsDialogOpen(true);
                      }}
                    >
                      <CreditCard className="h-4 w-4 mr-2" />
                      Pay
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
              {companies.filter(c => Number(c.outstanding_bill) > 0).length === 0 && (
                <TableRow>
                  <TableCell colSpan={3} className="text-center text-muted-foreground">
                    No outstanding bills
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Payment History */}
      <Card className="medical-card">
        <CardHeader>
          <CardTitle>Payment History</CardTitle>
          <CardDescription>
            All recorded payments and their details
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Company</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Note</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {payments.map((payment) => (
                <TableRow key={payment.id}>
                  <TableCell>
                    {new Date(payment.created_at).toLocaleDateString()}
                  </TableCell>
                  <TableCell className="font-medium">
                    {payment.companies?.name}
                  </TableCell>
                  <TableCell className="text-success font-medium">
                    ${Number(payment.amount).toFixed(2)}
                  </TableCell>
                  <TableCell>
                    {payment.note || (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default Payments;