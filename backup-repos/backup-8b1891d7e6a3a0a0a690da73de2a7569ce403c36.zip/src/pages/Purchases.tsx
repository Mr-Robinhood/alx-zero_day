import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Plus, ShoppingCart, Package, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Purchase {
  id: string;
  company_id: string;
  product_id: string;
  quantity: number;
  unit_cost: number;
  total_cost: number;
  invoice_number: string | null;
  created_at: string;
  companies: { name: string };
  products: { name: string };
}

interface Company {
  id: string;
  name: string;
}

interface Product {
  id: string;
  name: string;
  barcode: string;
}

interface PurchaseItemForm {
  product_id: string;
  quantity: string; // keep as string for input handling
  unit_cost: string;
  expiration_date?: string;
  markup_percentage?: string;
  calculated_sell_price?: string;
  notes?: string;
}

const Purchases = () => {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [showNewCompanyForm, setShowNewCompanyForm] = useState(false);
  
  const [batchForm, setBatchForm] = useState({
    company_id: '',
    invoice_number: '',
  });

  const [items, setItems] = useState<PurchaseItemForm[]>([
    { product_id: '', quantity: '', unit_cost: '', expiration_date: '', markup_percentage: '', calculated_sell_price: '' }
  ]);

  const [newCompanyForm, setNewCompanyForm] = useState({
    name: '',
    contact_person: '',
    email: '',
    phone: '',
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // Fetch purchases with company and product names
      const { data: purchasesData, error: purchasesError } = await supabase
        .from('purchases')
        .select(`
          *,
          companies(name),
          products(name)
        `)
        .order('created_at', { ascending: false });

      if (purchasesError) throw purchasesError;

      // Fetch companies
      const { data: companiesData, error: companiesError } = await supabase
        .from('companies')
        .select('id, name')
        .order('name');

      if (companiesError) throw companiesError;

      // Fetch products
      const { data: productsData, error: productsError } = await supabase
        .from('products')
        .select('id, name, barcode')
        .order('name');

      if (productsError) throw productsError;

      setPurchases(purchasesData || []);
      setCompanies(companiesData || []);
      setProducts(productsData || []);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast({
        title: "Error",
        description: "Failed to load data.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setBatchForm({ company_id: '', invoice_number: '' });
    setItems([{ product_id: '', quantity: '', unit_cost: '', expiration_date: '', markup_percentage: '', calculated_sell_price: '' }]);
    setNewCompanyForm({ name: '', contact_person: '', email: '', phone: '' });
    setShowNewCompanyForm(false);
  };

  const handleCreateCompany = async () => {
    try {
      const { data, error } = await supabase
        .from('companies')
        .insert([{ 
          name: newCompanyForm.name,
          contact_person: newCompanyForm.contact_person || null,
          email: newCompanyForm.email || null,
          phone: newCompanyForm.phone || null,
        }])
        .select()
        .single();

      if (error) throw error;

      // Add new company to the list and select it
      setCompanies(prev => [...prev, data]);
      setBatchForm(prev => ({ ...prev, company_id: data.id }));
      setShowNewCompanyForm(false);
      setNewCompanyForm({ name: '', contact_person: '', email: '', phone: '' });

      toast({
        title: "Company created",
        description: `${newCompanyForm.name} has been added and selected.`,
      });
    } catch (error: any) {
      console.error('Error creating company:', error);
      toast({
        title: "Failed to create company",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      });
    }
  };

  const addItem = () => {
    setItems(prev => [...prev, { product_id: '', quantity: '', unit_cost: '', expiration_date: '', markup_percentage: '', calculated_sell_price: '' }]);
  };

  const removeItem = (index: number) => {
    setItems(prev => prev.filter((_, i) => i !== index));
  };

  const updateItemField = (index: number, field: keyof PurchaseItemForm, value: string) => {
    setItems(prev => prev.map((item, i) => i === index ? { ...item, [field]: value } : item));
  };

  const parseNumber = (val?: string) => {
    const n = parseFloat(val || '');
    return isNaN(n) ? 0 : n;
    };

  const isValid = () => {
    if (!batchForm.company_id) return false;
    if (items.length === 0) return false;
    for (const item of items) {
      if (!item.product_id) return false;
      if (parseNumber(item.quantity) <= 0) return false;
      if (parseNumber(item.unit_cost) <= 0) return false;
    }
    return true;
  };

  const totalBatchCost = items.reduce((sum, item) => sum + (parseNumber(item.unit_cost) * parseNumber(item.quantity)), 0);

  const handleCreatePurchase = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isValid()) return;
    setCreating(true);

    try {
      const payloadItems = items.map(it => ({
        product_id: it.product_id,
        quantity: parseInt(it.quantity || '0', 10),
        unit_cost: parseFloat(it.unit_cost || '0'),
        expiration_date: it.expiration_date || null,
        markup_percentage: it.markup_percentage ? parseFloat(it.markup_percentage) : null,
        calculated_sell_price: it.calculated_sell_price ? parseFloat(it.calculated_sell_price) : null,
        notes: it.notes || null,
      }));

      const { data, error } = await supabase.rpc('record_purchases', {
        p_company_id: batchForm.company_id,
        p_invoice_number: batchForm.invoice_number || null,
        p_items: payloadItems,
      } as any);

      if (error) throw error;

      toast({
        title: "Purchase recorded, inventory and company bill updated.",
        description: `Total: $${totalBatchCost.toFixed(2)}`,
      });

      resetForm();
      setIsDialogOpen(false);
      await fetchData();
    } catch (error: any) {
      console.error('Error recording purchase:', error);
      toast({
        title: "Failed to record purchase",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setCreating(false);
    }
  };

  const openCreateDialog = () => {
    resetForm();
    setIsDialogOpen(true);
  };

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-8 bg-muted rounded w-1/4"></div>
        <div className="h-96 bg-muted rounded-lg"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center space-x-3">
            <ShoppingCart className="h-8 w-8 text-primary" />
            <span>Purchases</span>
          </h1>
          <p className="text-muted-foreground mt-1">
            Record purchases and update inventory automatically
          </p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="medical-gradient" onClick={openCreateDialog}>
              <Plus className="h-4 w-4 mr-2" />
              New Purchase
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-2">
                <ShoppingCart className="h-5 w-5" />
                <span>New Purchase</span>
              </DialogTitle>
              <DialogDescription>
                Add one or more items to this purchase
              </DialogDescription>
            </DialogHeader>

            <form onSubmit={handleCreatePurchase} className="space-y-4">
              {/* Company Selection */}
              <div className="space-y-2">
                <Label htmlFor="company">Company</Label>
                {!showNewCompanyForm ? (
                  <div className="flex space-x-2">
                    <Select value={batchForm.company_id} onValueChange={(value) => setBatchForm({ ...batchForm, company_id: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a company" />
                      </SelectTrigger>
                      <SelectContent>
                        {companies.map((company) => (
                          <SelectItem key={company.id} value={company.id}>
                            {company.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button type="button" variant="outline" onClick={() => setShowNewCompanyForm(true)}>
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3 p-4 border rounded-lg">
                    <div className="flex justify-between items-center">
                      <span className="font-medium">Add New Company</span>
                      <Button type="button" variant="ghost" size="sm" onClick={() => setShowNewCompanyForm(false)}>
                        Cancel
                      </Button>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <Input
                        placeholder="Company name"
                        value={newCompanyForm.name}
                        onChange={(e) => setNewCompanyForm({ ...newCompanyForm, name: e.target.value })}
                        required
                      />
                      <Input
                        placeholder="Contact person"
                        value={newCompanyForm.contact_person}
                        onChange={(e) => setNewCompanyForm({ ...newCompanyForm, contact_person: e.target.value })}
                      />
                      <Input
                        placeholder="Email"
                        type="email"
                        value={newCompanyForm.email}
                        onChange={(e) => setNewCompanyForm({ ...newCompanyForm, email: e.target.value })}
                      />
                      <Input
                        placeholder="Phone"
                        value={newCompanyForm.phone}
                        onChange={(e) => setNewCompanyForm({ ...newCompanyForm, phone: e.target.value })}
                      />
                    </div>
                    <Button type="button" onClick={handleCreateCompany} size="sm">
                      Add Company
                    </Button>
                  </div>
                )}
              </div>

              {/* Invoice number */}
              <div className="space-y-2">
                <Label htmlFor="invoice_number">Invoice Number (Optional)</Label>
                <Input
                  id="invoice_number"
                  type="text"
                  placeholder="INV-2025-001"
                  value={batchForm.invoice_number}
                  onChange={(e) => setBatchForm({ ...batchForm, invoice_number: e.target.value })}
                />
              </div>

              {/* Items */}
              <div className="space-y-4">
                {items.map((item, index) => {
                  const qty = parseNumber(item.quantity);
                  const unitCost = parseNumber(item.unit_cost);
                  const markup = parseNumber(item.markup_percentage);
                  const clientSell = item.calculated_sell_price ? parseNumber(item.calculated_sell_price) : 0;
                  const computedSell = clientSell > 0 ? clientSell : (unitCost * (1 + (markup / 100)));
                  const lineTotal = unitCost * qty;

                  return (
                    <div key={index} className="p-4 border rounded-lg space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">Item {index + 1}</span>
                        {items.length > 1 && (
                          <Button type="button" variant="ghost" size="sm" onClick={() => removeItem(index)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
                        <div className="col-span-2 space-y-1">
                          <Label>Product</Label>
                          <Select value={item.product_id} onValueChange={(value) => updateItemField(index, 'product_id', value)}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a product" />
                            </SelectTrigger>
                            <SelectContent>
                              {products.map((product) => (
                                <SelectItem key={product.id} value={product.id}>
                                  {product.name} ({product.barcode})
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-1">
                          <Label>Quantity</Label>
                          <Input type="number" min={1} value={item.quantity} onChange={(e) => updateItemField(index, 'quantity', e.target.value)} />
                          {parseNumber(item.quantity) <= 0 && (
                            <div className="text-xs text-destructive">Enter a quantity greater than 0</div>
                          )}
                        </div>
                        <div className="space-y-1">
                          <Label>Unit Cost</Label>
                          <Input type="number" step="0.01" min={0} value={item.unit_cost} onChange={(e) => updateItemField(index, 'unit_cost', e.target.value)} />
                          {parseNumber(item.unit_cost) <= 0 && (
                            <div className="text-xs text-destructive">Enter a unit cost greater than 0</div>
                          )}
                        </div>
                        <div className="space-y-1">
                          <Label>Expiration</Label>
                          <Input type="date" value={item.expiration_date || ''} onChange={(e) => updateItemField(index, 'expiration_date', e.target.value)} />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
                        <div className="space-y-1">
                          <Label>Markup %</Label>
                          <Input type="number" step="0.01" min={0} value={item.markup_percentage || ''} onChange={(e) => updateItemField(index, 'markup_percentage', e.target.value)} />
                        </div>
                        <div className="space-y-1">
                          <Label>Selling Price</Label>
                          <Input type="number" step="0.01" min={0} value={item.calculated_sell_price || ''} onChange={(e) => updateItemField(index, 'calculated_sell_price', e.target.value)} />
                        </div>
                        <div className="md:col-span-2 flex items-end">
                          <div className="text-sm text-muted-foreground">
                            Computed sell: <span className="font-medium">${isFinite(computedSell) ? computedSell.toFixed(2) : '0.00'}</span>
                          </div>
                        </div>
                        <div className="flex items-end justify-end">
                          <div className="text-sm font-medium">Line total: ${isFinite(lineTotal) ? lineTotal.toFixed(2) : '0.00'}</div>
                        </div>
                      </div>
                    </div>
                  );
                })}
                <div>
                  <Button type="button" variant="outline" onClick={addItem}>
                    <Plus className="h-4 w-4 mr-2" /> Add Item
                  </Button>
                </div>
              </div>

              {/* Total Cost Display */}
              <div className="p-3 bg-accent rounded-lg flex items-center justify-between">
                <span className="font-medium">Total Cost</span>
                <span className="text-lg font-bold text-primary">${isFinite(totalBatchCost) ? totalBatchCost.toFixed(2) : '0.00'}</span>
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  className="medical-gradient" 
                  disabled={creating || !isValid()}
                >
                  {creating ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    'Save Purchase'
                  )}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid gap-6 md:grid-cols-3">
        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Purchases
            </CardTitle>
            <ShoppingCart className="h-5 w-5 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">
              {purchases.length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Purchase records
            </p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Value
            </CardTitle>
            <Package className="h-5 w-5 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-success">
              ${purchases.reduce((total, purchase) => total + Number(purchase.total_cost), 0).toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              All purchases
            </p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              This Month
            </CardTitle>
            <ShoppingCart className="h-5 w-5 text-info" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-info">
              {purchases.filter(p => {
                const purchaseDate = new Date(p.created_at);
                const currentDate = new Date();
                return purchaseDate.getMonth() === currentDate.getMonth() && 
                       purchaseDate.getFullYear() === currentDate.getFullYear();
              }).length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Purchases this month
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Purchase History Table */}
      <Card className="medical-card">
        <CardHeader>
          <CardTitle>Purchase History</CardTitle>
          <CardDescription>
            All recorded purchases and their details
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Company</TableHead>
                <TableHead>Product</TableHead>
                <TableHead>Quantity</TableHead>
                <TableHead>Unit Cost</TableHead>
                <TableHead>Total Cost</TableHead>
                <TableHead>Invoice</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {purchases.map((purchase) => (
                <TableRow key={purchase.id}>
                  <TableCell>
                    {new Date(purchase.created_at).toLocaleDateString()}
                  </TableCell>
                  <TableCell className="font-medium">
                    {purchase.companies?.name}
                  </TableCell>
                  <TableCell>
                    {purchase.products?.name}
                  </TableCell>
                  <TableCell>{purchase.quantity}</TableCell>
                  <TableCell>${Number(purchase.unit_cost).toFixed(2)}</TableCell>
                  <TableCell className="font-medium">
                    ${Number(purchase.total_cost).toFixed(2)}
                  </TableCell>
                  <TableCell>
                    {purchase.invoice_number || (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default Purchases;