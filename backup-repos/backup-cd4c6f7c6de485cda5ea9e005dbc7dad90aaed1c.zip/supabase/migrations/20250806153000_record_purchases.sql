-- Drop previous trigger-based purchase handler to avoid double updates
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'handle_purchase_insert_trigger'
  ) THEN
    DROP TRIGGER handle_purchase_insert_trigger ON public.purchases;
  END IF;
  IF EXISTS (
    SELECT 1 FROM pg_proc WHERE proname = 'handle_purchase_insert'
  ) THEN
    DROP FUNCTION public.handle_purchase_insert();
  END IF;
END $$;

-- Create RPC to record multi-item purchases atomically
CREATE OR REPLACE FUNCTION public.record_purchases(
  p_company_id UUID,
  p_invoice_number TEXT,
  p_items JSONB
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_user_id UUID := auth.uid();
  v_total_cost NUMERIC := 0;
  v_purchase_ids UUID[] := ARRAY[]::UUID[];
BEGIN
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  IF p_company_id IS NULL THEN
    RAISE EXCEPTION 'company_id is required';
  END IF;

  IF p_items IS NULL OR jsonb_typeof(p_items) <> 'array' OR jsonb_array_length(p_items) = 0 THEN
    RAISE EXCEPTION 'items must be a non-empty array';
  END IF;

  -- Stage items in a temp table with computed fields
  CREATE TEMP TABLE _tmp_items (
    line_index INT,
    product_id UUID NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    unit_cost NUMERIC NOT NULL CHECK (unit_cost > 0),
    expiration_date DATE NULL,
    markup_percentage NUMERIC NULL,
    calculated_sell_price NUMERIC NULL,
    computed_sell_price NUMERIC NOT NULL,
    notes TEXT NULL
  ) ON COMMIT DROP;

  INSERT INTO _tmp_items (line_index, product_id, quantity, unit_cost, expiration_date, markup_percentage, calculated_sell_price, computed_sell_price, notes)
  SELECT
    elem.ordinality::INT AS line_index,
    (elem.value->>'product_id')::UUID AS product_id,
    NULLIF((elem.value->>'quantity')::INT, 0) AS quantity,
    (elem.value->>'unit_cost')::NUMERIC AS unit_cost,
    NULLIF(elem.value->>'expiration_date', '')::DATE AS expiration_date,
    NULLIF((elem.value->>'markup_percentage')::NUMERIC, 0) AS markup_percentage,
    NULLIF((elem.value->>'calculated_sell_price')::NUMERIC, 0) AS calculated_sell_price,
    COALESCE(
      NULLIF((elem.value->>'calculated_sell_price')::NUMERIC, 0),
      ((elem.value->>'unit_cost')::NUMERIC * (1 + COALESCE((elem.value->>'markup_percentage')::NUMERIC, 0) / 100.0))
    ) AS computed_sell_price,
    elem.value->>'notes' AS notes
  FROM jsonb_array_elements(p_items) WITH ORDINALITY AS elem(value, ordinality);

  -- Validate rows
  IF EXISTS (SELECT 1 FROM _tmp_items WHERE product_id IS NULL OR quantity IS NULL OR quantity <= 0 OR unit_cost IS NULL OR unit_cost <= 0) THEN
    RAISE EXCEPTION 'Each item must include product_id, quantity>0, unit_cost>0';
  END IF;

  -- Insert purchase lines and accumulate total cost, collecting ids
  INSERT INTO public.purchases (company_id, product_id, quantity, unit_cost, total_cost, invoice_number, user_id)
  SELECT 
    p_company_id,
    ti.product_id,
    ti.quantity,
    ti.unit_cost,
    (ti.quantity * ti.unit_cost) AS total_cost,
    NULLIF(p_invoice_number, '') AS invoice_number,
    v_user_id
  FROM _tmp_items ti
  RETURNING id
  INTO v_purchase_ids;

  -- Compute the total cost
  SELECT COALESCE(SUM(quantity * unit_cost), 0) INTO v_total_cost FROM _tmp_items;

  -- Update products: aggregate by product, sum quantities; price from last line; expiration when previous qty was 0
  WITH agg AS (
    SELECT 
      product_id,
      SUM(quantity) AS sum_qty,
      (SELECT computed_sell_price FROM _tmp_items t2 WHERE t2.product_id = t1.product_id ORDER BY line_index DESC LIMIT 1) AS new_price,
      (SELECT expiration_date FROM _tmp_items t2 WHERE t2.product_id = t1.product_id AND t2.expiration_date IS NOT NULL ORDER BY line_index DESC LIMIT 1) AS new_expiration
    FROM _tmp_items t1
    GROUP BY product_id
  )
  UPDATE public.products p
  SET 
    quantity = p.quantity + a.sum_qty,
    price = a.new_price,
    expiration_date = CASE 
      WHEN p.quantity = 0 AND a.new_expiration IS NOT NULL THEN a.new_expiration
      ELSE p.expiration_date
    END,
    updated_at = now()
  FROM agg a
  WHERE p.id = a.product_id;

  -- Update company bill
  UPDATE public.companies c
  SET outstanding_bill = c.outstanding_bill + v_total_cost,
      updated_at = now()
  WHERE c.id = p_company_id;

  -- Return ids and totals
  RETURN jsonb_build_object(
    'success', true,
    'purchase_ids', v_purchase_ids,
    'total_cost', v_total_cost
  );
EXCEPTION WHEN OTHERS THEN
  RAISE; -- will rollback due to function failure
END;
$$;

-- Grant execute to authenticated users
GRANT EXECUTE ON FUNCTION public.record_purchases(UUID, TEXT, JSONB) TO authenticated;