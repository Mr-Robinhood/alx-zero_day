import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  ShoppingCart, 
  Scan, 
  Plus, 
  Minus, 
  Trash2, 
  DollarSign,
  CreditCard,
  Receipt,
  Clock,
  Search
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Product {
  id: string;
  name: string;
  barcode: string;
  price: number;
  quantity: number;
}

interface CartItem extends Product {
  cartQuantity: number;
  subtotal: number;
}

interface Session {
  id: string;
  status: string;
  start_time: string;
  end_time?: string;
  created_at?: string;
  user_id?: string;
}

const POS = () => {
  const { user, profile } = useAuth();
  const { toast } = useToast();
  const [products, setProducts] = useState<Product[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [currentSession, setCurrentSession] = useState<Session | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [barcode, setBarcode] = useState('');
  const [loading, setLoading] = useState(true);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    fetchProducts();
    checkActiveSession();
  }, []);

  const fetchProducts = async () => {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('name');

      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      console.error('Error fetching products:', error);
      toast({
        title: "Error",
        description: "Failed to load products.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const checkActiveSession = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('sessions')
        .select('*')
        .eq('user_id', user.id)
        .eq('status', 'active')
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      setCurrentSession(data);
    } catch (error) {
      console.error('Error checking session:', error);
    }
  };

  const startSession = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('sessions')
        .insert({
          user_id: user.id,
          status: 'active',
        })
        .select()
        .single();

      if (error) throw error;
      
      setCurrentSession(data);
      toast({
        title: "Session started",
        description: "POS session is now active.",
      });
    } catch (error) {
      console.error('Error starting session:', error);
      toast({
        title: "Error",
        description: "Failed to start POS session.",
        variant: "destructive",
      });
    }
  };

  const endSession = async () => {
    if (!currentSession) return;

    try {
      const { error } = await supabase
        .from('sessions')
        .update({ 
          status: 'completed',
          end_time: new Date().toISOString(),
        })
        .eq('id', currentSession.id);

      if (error) throw error;

      setCurrentSession(null);
      setCart([]);
      toast({
        title: "Session ended",
        description: "POS session has been closed.",
      });
    } catch (error) {
      console.error('Error ending session:', error);
      toast({
        title: "Error",
        description: "Failed to end POS session.",
        variant: "destructive",
      });
    }
  };

  const addToCart = (product: Product) => {
    if (product.quantity <= 0) {
      toast({
        title: "Out of stock",
        description: `${product.name} is currently out of stock.`,
        variant: "destructive",
      });
      return;
    }

    const existingItem = cart.find(item => item.id === product.id);
    
    if (existingItem) {
      if (existingItem.cartQuantity >= product.quantity) {
        toast({
          title: "Insufficient stock",
          description: `Only ${product.quantity} units available.`,
          variant: "destructive",
        });
        return;
      }
      
      setCart(cart.map(item =>
        item.id === product.id
          ? { 
              ...item, 
              cartQuantity: item.cartQuantity + 1,
              subtotal: (item.cartQuantity + 1) * item.price
            }
          : item
      ));
    } else {
      setCart([...cart, {
        ...product,
        cartQuantity: 1,
        subtotal: product.price
      }]);
    }
  };

  const updateCartQuantity = (productId: string, newQuantity: number) => {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    if (newQuantity <= 0) {
      removeFromCart(productId);
      return;
    }

    if (newQuantity > product.quantity) {
      toast({
        title: "Insufficient stock",
        description: `Only ${product.quantity} units available.`,
        variant: "destructive",
      });
      return;
    }

    setCart(cart.map(item =>
      item.id === productId
        ? { 
            ...item, 
            cartQuantity: newQuantity,
            subtotal: newQuantity * item.price
          }
        : item
    ));
  };

  const removeFromCart = (productId: string) => {
    setCart(cart.filter(item => item.id !== productId));
  };

  const searchProduct = (term: string) => {
    const product = products.find(p => 
      p.barcode.toLowerCase().includes(term.toLowerCase()) ||
      p.name.toLowerCase().includes(term.toLowerCase())
    );
    
    if (product) {
      addToCart(product);
      setBarcode('');
      setSearchTerm('');
    } else {
      toast({
        title: "Product not found",
        description: "No product matches the search criteria.",
        variant: "destructive",
      });
    }
  };

  const processSale = async () => {
    if (!currentSession || cart.length === 0 || !user) return;

    setProcessing(true);

    try {
      // Create sales records
      const salesData = cart.map(item => ({
        session_id: currentSession.id,
        user_id: user.id,
        product_id: item.id,
        quantity: item.cartQuantity,
        unit_price: item.price,
        total_price: item.subtotal,
      }));

      const { error: salesError } = await supabase
        .from('sales')
        .insert(salesData);

      if (salesError) throw salesError;

      // Update product quantities
      for (const item of cart) {
        const { error: updateError } = await supabase
          .from('products')
          .update({ quantity: item.quantity - item.cartQuantity })
          .eq('id', item.id);

        if (updateError) throw updateError;
      }

      // Clear cart and refresh products
      setCart([]);
      setIsCheckoutOpen(false);
      fetchProducts();

      toast({
        title: "Sale completed",
        description: `Transaction processed successfully. Total: $${getTotalAmount().toFixed(2)}`,
      });

    } catch (error) {
      console.error('Error processing sale:', error);
      toast({
        title: "Transaction failed",
        description: "Failed to process the sale. Please try again.",
        variant: "destructive",
      });
    } finally {
      setProcessing(false);
    }
  };

  const getTotalAmount = () => {
    return cart.reduce((total, item) => total + item.subtotal, 0);
  };

  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.barcode.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-8 bg-muted rounded w-1/4"></div>
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 h-96 bg-muted rounded-lg"></div>
          <div className="h-96 bg-muted rounded-lg"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center space-x-3">
            <ShoppingCart className="h-8 w-8 text-primary" />
            <span>Point of Sale</span>
          </h1>
          <p className="text-muted-foreground mt-1">
            Process sales and manage transactions
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          {currentSession ? (
            <>
              <Badge className="status-active">
                <Clock className="h-3 w-3 mr-1" />
                Session Active
              </Badge>
              <Button variant="outline" onClick={endSession}>
                End Session
              </Button>
            </>
          ) : (
            <Button onClick={startSession} className="medical-gradient">
              <Clock className="h-4 w-4 mr-2" />
              Start Session
            </Button>
          )}
        </div>
      </div>

      {/* Main POS Interface */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Products Section */}
        <div className="lg:col-span-2 space-y-4">
          {/* Search and Barcode Scanner */}
          <Card className="medical-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Scan className="h-5 w-5" />
                <span>Product Search</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex space-x-2">
                <div className="flex-1">
                  <Label htmlFor="search">Search Products</Label>
                  <Input
                    id="search"
                    placeholder="Search by name..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    disabled={!currentSession}
                  />
                </div>
                <div className="flex-1">
                  <Label htmlFor="barcode">Barcode Scanner</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="barcode"
                      placeholder="Scan or enter barcode"
                      value={barcode}
                      onChange={(e) => setBarcode(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && searchProduct(barcode)}
                      disabled={!currentSession}
                    />
                    <Button 
                      onClick={() => searchProduct(barcode)}
                      disabled={!currentSession || !barcode}
                    >
                      <Search className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Products Grid */}
          <Card className="medical-card">
            <CardHeader>
              <CardTitle>Available Products</CardTitle>
              <CardDescription>
                Click to add products to cart
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="grid gap-3 md:grid-cols-2">
                  {filteredProducts.map((product) => (
                    <Card 
                      key={product.id} 
                      className={`cursor-pointer transition-all hover:shadow-md ${
                        !currentSession ? 'opacity-50' : ''
                      } ${product.quantity <= 0 ? 'opacity-40' : ''}`}
                      onClick={() => currentSession && addToCart(product)}
                    >
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <h4 className="font-medium text-sm">{product.name}</h4>
                            <p className="text-xs text-muted-foreground">{product.barcode}</p>
                            <p className="text-lg font-bold text-primary mt-1">
                              ${product.price.toFixed(2)}
                            </p>
                          </div>
                          <Badge 
                            variant={product.quantity > 0 ? "secondary" : "destructive"}
                            className="text-xs"
                          >
                            {product.quantity} in stock
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </div>

        {/* Cart Section */}
        <div className="space-y-4">
          <Card className="medical-card">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Shopping Cart</span>
                <Badge variant="outline">{cart.length} items</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-64">
                {cart.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">
                    Cart is empty
                  </p>
                ) : (
                  <div className="space-y-3">
                    {cart.map((item) => (
                      <div key={item.id} className="flex items-center space-x-2 p-2 border rounded">
                        <div className="flex-1">
                          <p className="font-medium text-sm">{item.name}</p>
                          <p className="text-xs text-muted-foreground">
                            ${item.price.toFixed(2)} each
                          </p>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => updateCartQuantity(item.id, item.cartQuantity - 1)}
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <span className="w-8 text-center text-sm">{item.cartQuantity}</span>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => updateCartQuantity(item.id, item.cartQuantity + 1)}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="destructive"
                            onClick={() => removeFromCart(item.id)}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                        <div className="text-right">
                          <p className="font-medium text-sm">${item.subtotal.toFixed(2)}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
              
              {cart.length > 0 && (
                <>
                  <Separator className="my-4" />
                  <div className="space-y-2">
                    <div className="flex justify-between text-lg font-bold">
                      <span>Total:</span>
                      <span className="text-primary">${getTotalAmount().toFixed(2)}</span>
                    </div>
                    <Dialog open={isCheckoutOpen} onOpenChange={setIsCheckoutOpen}>
                      <DialogTrigger asChild>
                        <Button 
                          className="w-full medical-gradient"
                          disabled={!currentSession || cart.length === 0}
                        >
                          <CreditCard className="h-4 w-4 mr-2" />
                          Checkout
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-md">
                        <DialogHeader>
                          <DialogTitle className="flex items-center space-x-2">
                            <Receipt className="h-5 w-5" />
                            <span>Complete Sale</span>
                          </DialogTitle>
                          <DialogDescription>
                            Review the transaction and process payment.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>Item</TableHead>
                                <TableHead>Qty</TableHead>
                                <TableHead>Total</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {cart.map((item) => (
                                <TableRow key={item.id}>
                                  <TableCell className="font-medium">{item.name}</TableCell>
                                  <TableCell>{item.cartQuantity}</TableCell>
                                  <TableCell>${item.subtotal.toFixed(2)}</TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                          <Separator />
                          <div className="flex justify-between text-lg font-bold">
                            <span>Total Amount:</span>
                            <span className="text-primary">${getTotalAmount().toFixed(2)}</span>
                          </div>
                        </div>
                        <DialogFooter>
                          <Button variant="outline" onClick={() => setIsCheckoutOpen(false)}>
                            Cancel
                          </Button>
                          <Button 
                            onClick={processSale}
                            className="medical-gradient" 
                            disabled={processing}
                          >
                            {processing ? (
                              <>
                                <DollarSign className="mr-2 h-4 w-4 animate-spin" />
                                Processing...
                              </>
                            ) : (
                              <>
                                <DollarSign className="mr-2 h-4 w-4" />
                                Complete Sale
                              </>
                            )}
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default POS;