import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Loader2, Plus, UserPlus, Users, Trash2, ShoppingCart } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Navigate } from 'react-router-dom';

interface Cashier {
  id: string;
  user_id: string;
  full_name: string;
  role: 'admin' | 'cashier';
  created_at: string;
}

const CashierManagement = () => {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [cashiers, setCashiers] = useState<Cashier[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [deleting, setDeleting] = useState<string | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  const [newCashier, setNewCashier] = useState({
    email: '',
    password: '',
    fullName: '',
  });

  // Only admins can access this page
  if (profile?.role !== 'admin') {
    return <Navigate to="/" replace />;
  }

  useEffect(() => {
    fetchCashiers();
  }, []);

  const fetchCashiers = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('role', 'cashier')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setCashiers(data || []);
    } catch (error) {
      console.error('Error fetching cashiers:', error);
      toast({
        title: "Error",
        description: "Failed to load cashier profiles.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreateCashier = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreating(true);

    if (newCashier.password.length < 6) {
      toast({
        title: "Password too short",
        description: "Password must be at least 6 characters long",
        variant: "destructive",
      });
      setCreating(false);
      return;
    }

    try {
      // Create cashier user via Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: newCashier.email,
        password: newCashier.password,
        options: {
          data: {
            full_name: newCashier.fullName,
            role: 'cashier',
          },
          emailRedirectTo: `${window.location.origin}/`,
        },
      });

      if (authError) throw authError;

      if (authData.user) {
        toast({
          title: "Cashier created successfully",
          description: `${newCashier.fullName} has been added as a cashier.`,
        });

        // Reset form and close dialog
        setNewCashier({
          email: '',
          password: '',
          fullName: '',
        });
        setIsDialogOpen(false);
        
        // Refresh the cashiers list
        fetchCashiers();
      }
    } catch (error: any) {
      console.error('Error creating cashier:', error);
      toast({
        title: "Failed to create cashier",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setCreating(false);
    }
  };

  const handleDeleteCashier = async (cashierId: string, cashierName: string) => {
    setDeleting(cashierId);
    
    try {
      // Delete the cashier profile
      const { error } = await supabase
        .from('profiles')
        .delete()
        .eq('id', cashierId);

      if (error) throw error;

      toast({
        title: "Cashier deleted successfully",
        description: `Cashier ${cashierName} has been removed from the system.`,
      });

      // Refresh the cashiers list
      fetchCashiers();
    } catch (error: any) {
      console.error('Error deleting cashier:', error);
      toast({
        title: "Failed to delete cashier",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setDeleting(null);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-8 bg-muted rounded w-1/4"></div>
        <div className="h-96 bg-muted rounded-lg"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center space-x-3">
            <ShoppingCart className="h-8 w-8 text-primary" />
            <span>Cashier Management</span>
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage cashier staff and their POS access
          </p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="medical-gradient">
              <Plus className="h-4 w-4 mr-2" />
              Add Cashier
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-2">
                <UserPlus className="h-5 w-5" />
                <span>Create New Cashier</span>
              </DialogTitle>
              <DialogDescription>
                Add a new cashier to the POS system.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreateCashier} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="full-name">Full Name</Label>
                <Input
                  id="full-name"
                  type="text"
                  placeholder="John Smith"
                  value={newCashier.fullName}
                  onChange={(e) => setNewCashier({ ...newCashier, fullName: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="john@pharmacy.com"
                  value={newCashier.email}
                  onChange={(e) => setNewCashier({ ...newCashier, email: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Minimum 6 characters"
                  value={newCashier.password}
                  onChange={(e) => setNewCashier({ ...newCashier, password: e.target.value })}
                  required
                />
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" className="medical-gradient" disabled={creating}>
                  {creating ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    'Create Cashier'
                  )}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Cashiers
            </CardTitle>
            <Users className="h-5 w-5 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">
              {cashiers.length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Active POS operators
            </p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Recently Added
            </CardTitle>
            <UserPlus className="h-5 w-5 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-success">
              {cashiers.filter(c => {
                const weekAgo = new Date();
                weekAgo.setDate(weekAgo.getDate() - 7);
                return new Date(c.created_at) > weekAgo;
              }).length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Added this week
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Cashiers Table */}
      <Card className="medical-card">
        <CardHeader>
          <CardTitle>Cashier Directory</CardTitle>
          <CardDescription>
            All registered cashiers and their POS access
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Created</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {cashiers.map((cashier) => (
                <TableRow key={cashier.id}>
                  <TableCell className="font-medium">{cashier.full_name}</TableCell>
                  <TableCell>
                    <Badge 
                      variant="secondary"
                      className="bg-success text-success-foreground"
                    >
                      Cashier
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {new Date(cashier.created_at).toLocaleDateString()}
                  </TableCell>
                  <TableCell>
                    <Badge className="status-active">Active</Badge>
                  </TableCell>
                  <TableCell>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-destructive hover:text-destructive"
                          disabled={deleting === cashier.id}
                        >
                          {deleting === cashier.id ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <Trash2 className="h-4 w-4" />
                          )}
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete Cashier</AlertDialogTitle>
                          <AlertDialogDescription>
                            Are you sure you want to delete {cashier.full_name}? This action cannot be undone
                            and will remove all associated POS data.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => handleDeleteCashier(cashier.id, cashier.full_name)}
                            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          >
                            Delete Cashier
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </TableCell>
                </TableRow>
              ))}
              {cashiers.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                    No cashiers found. Add your first cashier to get started.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default CashierManagement;