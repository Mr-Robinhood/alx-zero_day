import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  BarChart3, 
  DollarSign, 
  TrendingUp, 
  Calendar,
  Clock,
  FileText,
  Users
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface SessionSale {
  session_id: string;
  user_name: string;
  start_time: string;
  end_time: string | null;
  status: string;
  total_sales: number;
  total_revenue: number;
  items_sold: number;
}

interface SaleDetail {
  id: string;
  product_name: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  sale_time: string;
}

const Sales = () => {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [sessionSales, setSessionSales] = useState<SessionSale[]>([]);
  const [selectedSession, setSelectedSession] = useState<string | null>(null);
  const [saleDetails, setSaleDetails] = useState<SaleDetail[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterPeriod, setFilterPeriod] = useState('today');

  useEffect(() => {
    fetchSessionSales();
  }, [filterPeriod]);

  useEffect(() => {
    if (selectedSession) {
      fetchSaleDetails(selectedSession);
    }
  }, [selectedSession]);

  const getDateFilter = () => {
    const now = new Date();
    switch (filterPeriod) {
      case 'today':
        return now.toISOString().split('T')[0];
      case 'week':
        const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        return weekAgo.toISOString().split('T')[0];
      case 'month':
        const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        return monthAgo.toISOString().split('T')[0];
      default:
        return now.toISOString().split('T')[0];
    }
  };

  const fetchSessionSales = async () => {
    try {
      const startDate = getDateFilter();
      
      const { data, error } = await supabase
        .from('sessions')
        .select(`
          id,
          user_id,
          start_time,
          end_time,
          status,
          profiles!inner(full_name),
          sales(quantity, total_price)
        `)
        .gte('start_time', `${startDate}T00:00:00.000Z`)
        .order('start_time', { ascending: false });

      if (error) throw error;

      const sessionSales: SessionSale[] = data.map((session: any) => {
        const totalSales = session.sales.reduce((sum: number, sale: any) => sum + sale.quantity, 0);
        const totalRevenue = session.sales.reduce((sum: number, sale: any) => sum + Number(sale.total_price), 0);
        
        return {
          session_id: session.id,
          user_name: session.profiles.full_name,
          start_time: session.start_time,
          end_time: session.end_time,
          status: session.status,
          total_sales: totalSales,
          total_revenue: totalRevenue,
          items_sold: session.sales.length,
        };
      });

      setSessionSales(sessionSales);
    } catch (error) {
      console.error('Error fetching session sales:', error);
      toast({
        title: "Error",
        description: "Failed to load sales data.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchSaleDetails = async (sessionId: string) => {
    try {
      const { data, error } = await supabase
        .from('sales')
        .select(`
          id,
          quantity,
          unit_price,
          total_price,
          sale_time,
          products(name)
        `)
        .eq('session_id', sessionId)
        .order('sale_time', { ascending: false });

      if (error) throw error;

      const details: SaleDetail[] = data.map((sale: any) => ({
        id: sale.id,
        product_name: sale.products.name,
        quantity: sale.quantity,
        unit_price: Number(sale.unit_price),
        total_price: Number(sale.total_price),
        sale_time: sale.sale_time,
      }));

      setSaleDetails(details);
    } catch (error) {
      console.error('Error fetching sale details:', error);
      toast({
        title: "Error",
        description: "Failed to load sale details.",
        variant: "destructive",
      });
    }
  };

  const getTotals = () => {
    return sessionSales.reduce(
      (totals, session) => ({
        revenue: totals.revenue + session.total_revenue,
        sales: totals.sales + session.total_sales,
        sessions: totals.sessions + 1,
      }),
      { revenue: 0, sales: 0, sessions: 0 }
    );
  };

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString();
  };

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-8 bg-muted rounded w-1/4"></div>
        <div className="grid gap-6 md:grid-cols-3">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-32 bg-muted rounded-lg"></div>
          ))}
        </div>
        <div className="h-96 bg-muted rounded-lg"></div>
      </div>
    );
  }

  const totals = getTotals();

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center space-x-3">
            <BarChart3 className="h-8 w-8 text-primary" />
            <span>Sales Reports</span>
          </h1>
          <p className="text-muted-foreground mt-1">
            Detailed sales analytics and session reports
          </p>
        </div>
        
        <Select value={filterPeriod} onValueChange={setFilterPeriod}>
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="today">Today</SelectItem>
            <SelectItem value="week">Last 7 Days</SelectItem>
            <SelectItem value="month">Last 30 Days</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Summary Stats */}
      <div className="grid gap-6 md:grid-cols-3">
        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Revenue
            </CardTitle>
            <DollarSign className="h-5 w-5 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">
              ${totals.revenue.toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              From {totals.sessions} sessions
            </p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Items Sold
            </CardTitle>
            <TrendingUp className="h-5 w-5 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-success">
              {totals.sales}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Total items sold
            </p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Active Sessions
            </CardTitle>
            <Users className="h-5 w-5 text-info" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-info">
              {totals.sessions}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Sales sessions
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Sessions Table */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Clock className="h-5 w-5" />
              <span>Session Reports</span>
            </CardTitle>
            <CardDescription>
              Click on a session to view detailed sales
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Cashier</TableHead>
                  <TableHead>Start Time</TableHead>
                  <TableHead>Sales</TableHead>
                  <TableHead>Revenue</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sessionSales.map((session) => (
                  <TableRow 
                    key={session.session_id}
                    className={`cursor-pointer hover:bg-muted/50 ${
                      selectedSession === session.session_id ? 'bg-muted' : ''
                    }`}
                    onClick={() => setSelectedSession(session.session_id)}
                  >
                    <TableCell className="font-medium">{session.user_name}</TableCell>
                    <TableCell>
                      <div>
                        <div>{formatDate(session.start_time)}</div>
                        <div className="text-xs text-muted-foreground">
                          {formatTime(session.start_time)}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>{session.total_sales}</TableCell>
                    <TableCell className="text-primary font-medium">
                      ${session.total_revenue.toFixed(2)}
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant={session.status === 'completed' ? 'secondary' : 'default'}
                        className={session.status === 'active' ? 'status-active' : ''}
                      >
                        {session.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Sale Details */}
        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <FileText className="h-5 w-5" />
              <span>Sale Details</span>
            </CardTitle>
            <CardDescription>
              {selectedSession ? 'Items sold in selected session' : 'Select a session to view details'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {selectedSession ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Product</TableHead>
                    <TableHead>Qty</TableHead>
                    <TableHead>Price</TableHead>
                    <TableHead>Total</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {saleDetails.map((detail) => (
                    <TableRow key={detail.id}>
                      <TableCell className="font-medium">{detail.product_name}</TableCell>
                      <TableCell>{detail.quantity}</TableCell>
                      <TableCell>${detail.unit_price.toFixed(2)}</TableCell>
                      <TableCell className="text-primary font-medium">
                        ${detail.total_price.toFixed(2)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center text-muted-foreground py-8">
                Select a session to view detailed sales information
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Sales;