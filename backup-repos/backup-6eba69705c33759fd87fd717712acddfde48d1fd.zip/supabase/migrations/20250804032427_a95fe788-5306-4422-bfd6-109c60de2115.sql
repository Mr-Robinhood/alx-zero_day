-- Create a security definer function to get the current user's role
-- This function bypasses RLS to prevent infinite recursion
CREATE OR REPLACE FUNCTION public.get_current_user_role()
RETURNS TEXT AS $$
  SELECT role::text FROM public.profiles WHERE user_id = auth.uid();
$$ LANGUAGE SQL SECURITY DEFINER STABLE;

-- Drop the problematic admin policy and recreate it using the function
DROP POLICY IF EXISTS "Only admins can view all profiles" ON public.profiles;

-- Create new admin policy using the security definer function
CREATE POLICY "Admins can view all profiles" 
ON public.profiles 
FOR SELECT 
USING (public.get_current_user_role() = 'admin');

-- Also fix other policies that might have the same issue
DROP POLICY IF EXISTS "Admins can view all sessions" ON public.sessions;
CREATE POLICY "Admins can view all sessions" 
ON public.sessions 
FOR SELECT 
USING (public.get_current_user_role() = 'admin');

DROP POLICY IF EXISTS "Admins can view all sales" ON public.sales;
CREATE POLICY "Admins can view all sales" 
ON public.sales 
FOR SELECT 
USING (public.get_current_user_role() = 'admin');

-- Fix the products admin policy as well
DROP POLICY IF EXISTS "Only admins can manage products" ON public.products;
CREATE POLICY "Only admins can manage products" 
ON public.products 
FOR ALL 
USING (public.get_current_user_role() = 'admin');