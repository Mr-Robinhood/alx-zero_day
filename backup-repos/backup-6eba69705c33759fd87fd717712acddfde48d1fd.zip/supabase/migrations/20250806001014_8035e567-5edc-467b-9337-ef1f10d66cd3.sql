-- Fix the security warnings by setting search_path for all functions
CREATE OR REPLACE FUNCTION public.get_current_user_role()
 RETURNS text
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT role::text FROM public.profiles WHERE user_id = auth.uid();
$function$;

CREATE OR REPLACE FUNCTION public.handle_purchase_insert()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  -- Update product quantity
  UPDATE public.products 
  SET quantity = quantity + NEW.quantity,
      updated_at = now()
  WHERE id = NEW.product_id;
  
  -- Update company outstanding bill
  UPDATE public.companies 
  SET outstanding_bill = outstanding_bill + NEW.total_cost,
      updated_at = now()
  WHERE id = NEW.company_id;
  
  RETURN NEW;
END;
$function$;

CREATE OR REPLACE FUNCTION public.handle_payment_insert()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  -- Update company outstanding bill
  UPDATE public.companies 
  SET outstanding_bill = outstanding_bill - NEW.amount,
      updated_at = now()
  WHERE id = NEW.company_id;
  
  RETURN NEW;
END;
$function$;