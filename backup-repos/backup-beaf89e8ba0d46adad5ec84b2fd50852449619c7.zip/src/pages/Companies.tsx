import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Loader2, Plus, Building, Edit, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Textarea } from '@/components/ui/textarea';

interface Company {
  id: string;
  name: string;
  contact_person: string | null;
  email: string | null;
  phone: string | null;
  address: string | null;
  outstanding_bill: number;
  created_at: string;
}

const Companies = () => {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [editing, setEditing] = useState(false);
  const [deleting, setDeleting] = useState<string | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingCompany, setEditingCompany] = useState<Company | null>(null);
  
  const [companyForm, setCompanyForm] = useState({
    name: '',
    contact_person: '',
    email: '',
    phone: '',
    address: '',
  });

  useEffect(() => {
    fetchCompanies();
  }, []);

  const fetchCompanies = async () => {
    try {
      const { data, error } = await supabase
        .from('companies')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setCompanies(data || []);
    } catch (error) {
      console.error('Error fetching companies:', error);
      toast({
        title: "Error",
        description: "Failed to load companies.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setCompanyForm({
      name: '',
      contact_person: '',
      email: '',
      phone: '',
      address: '',
    });
    setEditingCompany(null);
  };

  const handleCreateCompany = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreating(true);

    try {
      const { error } = await supabase
        .from('companies')
        .insert([{
          name: companyForm.name,
          contact_person: companyForm.contact_person || null,
          email: companyForm.email || null,
          phone: companyForm.phone || null,
          address: companyForm.address || null,
        }]);

      if (error) throw error;

      toast({
        title: "Company created successfully",
        description: `${companyForm.name} has been added.`,
      });

      resetForm();
      setIsDialogOpen(false);
      fetchCompanies();
    } catch (error: any) {
      console.error('Error creating company:', error);
      toast({
        title: "Failed to create company",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setCreating(false);
    }
  };

  const handleEditCompany = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCompany) return;
    
    setEditing(true);

    try {
      const { error } = await supabase
        .from('companies')
        .update({
          name: companyForm.name,
          contact_person: companyForm.contact_person || null,
          email: companyForm.email || null,
          phone: companyForm.phone || null,
          address: companyForm.address || null,
        })
        .eq('id', editingCompany.id);

      if (error) throw error;

      toast({
        title: "Company updated successfully",
        description: `${companyForm.name} has been updated.`,
      });

      resetForm();
      setIsDialogOpen(false);
      fetchCompanies();
    } catch (error: any) {
      console.error('Error updating company:', error);
      toast({
        title: "Failed to update company",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setEditing(false);
    }
  };

  const handleDeleteCompany = async (companyId: string) => {
    if (profile?.role !== 'admin') {
      toast({
        title: "Access denied",
        description: "Only admins can delete companies.",
        variant: "destructive",
      });
      return;
    }

    setDeleting(companyId);

    try {
      const { error } = await supabase
        .from('companies')
        .delete()
        .eq('id', companyId);

      if (error) throw error;

      toast({
        title: "Company deleted",
        description: "The company has been removed.",
      });

      fetchCompanies();
    } catch (error: any) {
      console.error('Error deleting company:', error);
      toast({
        title: "Failed to delete company",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setDeleting(null);
    }
  };

  const openEditDialog = (company: Company) => {
    setEditingCompany(company);
    setCompanyForm({
      name: company.name,
      contact_person: company.contact_person || '',
      email: company.email || '',
      phone: company.phone || '',
      address: company.address || '',
    });
    setIsDialogOpen(true);
  };

  const openCreateDialog = () => {
    resetForm();
    setIsDialogOpen(true);
  };

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-8 bg-muted rounded w-1/4"></div>
        <div className="h-96 bg-muted rounded-lg"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center space-x-3">
            <Building className="h-8 w-8 text-primary" />
            <span>Companies</span>
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage suppliers and their outstanding bills
          </p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="medical-gradient" onClick={openCreateDialog}>
              <Plus className="h-4 w-4 mr-2" />
              Add Company
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-2">
                <Building className="h-5 w-5" />
                <span>{editingCompany ? 'Edit Company' : 'Add New Company'}</span>
              </DialogTitle>
              <DialogDescription>
                {editingCompany ? 'Update company information' : 'Add a new supplier company'}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={editingCompany ? handleEditCompany : handleCreateCompany} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Company Name</Label>
                <Input
                  id="name"
                  type="text"
                  placeholder="Acme Pharmaceuticals"
                  value={companyForm.name}
                  onChange={(e) => setCompanyForm({ ...companyForm, name: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="contact_person">Contact Person</Label>
                <Input
                  id="contact_person"
                  type="text"
                  placeholder="John Smith"
                  value={companyForm.contact_person}
                  onChange={(e) => setCompanyForm({ ...companyForm, contact_person: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="contact@company.com"
                    value={companyForm.email}
                    onChange={(e) => setCompanyForm({ ...companyForm, email: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="+1 (555) 123-4567"
                    value={companyForm.phone}
                    onChange={(e) => setCompanyForm({ ...companyForm, phone: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="address">Address</Label>
                <Textarea
                  id="address"
                  placeholder="Company address..."
                  value={companyForm.address}
                  onChange={(e) => setCompanyForm({ ...companyForm, address: e.target.value })}
                />
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  className="medical-gradient" 
                  disabled={creating || editing}
                >
                  {(creating || editing) ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      {editingCompany ? 'Updating...' : 'Creating...'}
                    </>
                  ) : (
                    editingCompany ? 'Update Company' : 'Create Company'
                  )}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid gap-6 md:grid-cols-3">
        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Companies
            </CardTitle>
            <Building className="h-5 w-5 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">
              {companies.length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Registered suppliers
            </p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Outstanding Bills
            </CardTitle>
            <Building className="h-5 w-5 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-warning">
              ${companies.reduce((total, company) => total + Number(company.outstanding_bill), 0).toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Total owed amount
            </p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Companies with Debt
            </CardTitle>
            <Building className="h-5 w-5 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">
              {companies.filter(c => Number(c.outstanding_bill) > 0).length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Need payment
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Companies Table */}
      <Card className="medical-card">
        <CardHeader>
          <CardTitle>Suppliers</CardTitle>
          <CardDescription>
            All supplier companies and their outstanding bills
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Company Name</TableHead>
                <TableHead>Contact</TableHead>
                <TableHead>Phone</TableHead>
                <TableHead>Outstanding Bill</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {companies.map((company) => (
                <TableRow key={company.id}>
                  <TableCell className="font-medium">
                    <div>
                      <div>{company.name}</div>
                      {company.email && (
                        <div className="text-sm text-muted-foreground">{company.email}</div>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    {company.contact_person || (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell>
                    {company.phone || (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <span className={Number(company.outstanding_bill) > 0 ? "text-destructive font-medium" : "text-muted-foreground"}>
                      ${Number(company.outstanding_bill).toFixed(2)}
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openEditDialog(company)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      {profile?.role === 'admin' && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteCompany(company.id)}
                          disabled={deleting === company.id}
                        >
                          {deleting === company.id ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <Trash2 className="h-4 w-4" />
                          )}
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default Companies;