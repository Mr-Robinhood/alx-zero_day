-- Create sale_items table for detailed sale line items
CREATE TABLE public.sale_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  sale_id UUID NOT NULL,
  product_id UUID NOT NULL,
  quantity INTEGER NOT NULL,
  unit_price NUMERIC NOT NULL,
  total_price NUMERIC NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add RLS policies for sale_items
ALTER TABLE public.sale_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own sale items"
ON public.sale_items
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.sales s 
    WHERE s.id = sale_items.sale_id 
    AND s.user_id = auth.uid()
  )
);

CREATE POLICY "Users can insert their own sale items"
ON public.sale_items
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.sales s 
    WHERE s.id = sale_items.sale_id 
    AND s.user_id = auth.uid()
  )
);

CREATE POLICY "Admins can view all sale items"
ON public.sale_items
FOR SELECT
USING (get_current_user_role() = 'admin');

-- Modify sales table to add payment method and make it a header table
ALTER TABLE public.sales 
ADD COLUMN payment_method TEXT CHECK (payment_method IN ('cash', 'bank')) DEFAULT 'cash',
ADD COLUMN total_amount NUMERIC NOT NULL DEFAULT 0,
ADD COLUMN amount_paid NUMERIC,
ADD COLUMN change_due NUMERIC DEFAULT 0;

-- Update the sales table to remove individual product fields (keeping for backward compatibility but will use sale_items going forward)
-- The existing sales table will serve as the sale header