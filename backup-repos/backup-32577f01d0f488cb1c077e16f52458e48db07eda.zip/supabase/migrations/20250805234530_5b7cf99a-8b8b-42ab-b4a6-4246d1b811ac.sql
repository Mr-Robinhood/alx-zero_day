-- Create companies table for suppliers
CREATE TABLE public.companies (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  contact_person TEXT,
  email TEXT,
  phone TEXT,
  address TEXT,
  outstanding_bill NUMERIC NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create purchases table
CREATE TABLE public.purchases (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  quantity INTEGER NOT NULL,
  unit_cost NUMERIC NOT NULL,
  total_cost NUMERIC NOT NULL,
  invoice_number TEXT,
  user_id UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create payments table for company bill payments
CREATE TABLE public.payments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  amount NUMERIC NOT NULL,
  note TEXT,
  user_id UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.companies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.purchases ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for companies
CREATE POLICY "All authenticated users can view companies" 
ON public.companies 
FOR SELECT 
USING (true);

CREATE POLICY "Only admins can manage companies" 
ON public.companies 
FOR ALL 
USING (get_current_user_role() = 'admin');

-- Create RLS policies for purchases
CREATE POLICY "All authenticated users can view purchases" 
ON public.purchases 
FOR SELECT 
USING (true);

CREATE POLICY "Authenticated users can insert purchases" 
ON public.purchases 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Only admins can update/delete purchases" 
ON public.purchases 
FOR UPDATE 
USING (get_current_user_role() = 'admin');

CREATE POLICY "Only admins can delete purchases" 
ON public.purchases 
FOR DELETE 
USING (get_current_user_role() = 'admin');

-- Create RLS policies for payments
CREATE POLICY "All authenticated users can view payments" 
ON public.payments 
FOR SELECT 
USING (true);

CREATE POLICY "Authenticated users can insert payments" 
ON public.payments 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Only admins can update/delete payments" 
ON public.payments 
FOR UPDATE 
USING (get_current_user_role() = 'admin');

CREATE POLICY "Only admins can delete payments" 
ON public.payments 
FOR DELETE 
USING (get_current_user_role() = 'admin');

-- Create trigger for companies updated_at
CREATE TRIGGER update_companies_updated_at
BEFORE UPDATE ON public.companies
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create function to update inventory and company bill when purchase is made
CREATE OR REPLACE FUNCTION public.handle_purchase_insert()
RETURNS TRIGGER AS $$
BEGIN
  -- Update product quantity
  UPDATE public.products 
  SET quantity = quantity + NEW.quantity,
      updated_at = now()
  WHERE id = NEW.product_id;
  
  -- Update company outstanding bill
  UPDATE public.companies 
  SET outstanding_bill = outstanding_bill + NEW.total_cost,
      updated_at = now()
  WHERE id = NEW.company_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for purchase insert
CREATE TRIGGER handle_purchase_insert_trigger
AFTER INSERT ON public.purchases
FOR EACH ROW
EXECUTE FUNCTION public.handle_purchase_insert();

-- Create function to update company bill when payment is made
CREATE OR REPLACE FUNCTION public.handle_payment_insert()
RETURNS TRIGGER AS $$
BEGIN
  -- Update company outstanding bill
  UPDATE public.companies 
  SET outstanding_bill = outstanding_bill - NEW.amount,
      updated_at = now()
  WHERE id = NEW.company_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for payment insert
CREATE TRIGGER handle_payment_insert_trigger
AFTER INSERT ON public.payments
FOR EACH ROW
EXECUTE FUNCTION public.handle_payment_insert();