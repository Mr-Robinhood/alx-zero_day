import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';

interface ActiveShift {
  id: string;
  user_id: string;
  start_time: string;
  status: string;
}

interface ShiftContextType {
  activeShift: ActiveShift | null;
  loading: boolean;
  startShift: () => Promise<boolean>;
  endShift: () => Promise<boolean>;
  checkActiveShift: () => Promise<void>;
}

const ShiftContext = createContext<ShiftContextType | undefined>(undefined);

export const useShift = () => {
  const context = useContext(ShiftContext);
  if (context === undefined) {
    throw new Error('useShift must be used within a ShiftProvider');
  }
  return context;
};

interface ShiftProviderProps {
  children: ReactNode;
}

export const ShiftProvider = ({ children }: ShiftProviderProps) => {
  const [activeShift, setActiveShift] = useState<ActiveShift | null>(null);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const { toast } = useToast();

  const checkActiveShift = async () => {
    if (!user) {
      setActiveShift(null);
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('sessions')
        .select('id, user_id, start_time, status')
        .eq('user_id', user.id)
        .eq('status', 'active')
        .order('start_time', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) {
        console.error('Error checking active shift:', error);
        return;
      }

      setActiveShift(data);
    } catch (error) {
      console.error('Error checking active shift:', error);
    } finally {
      setLoading(false);
    }
  };

  const startShift = async (): Promise<boolean> => {
    if (!user) {
      toast({
        title: "Error",
        description: "You must be logged in to start a shift.",
        variant: "destructive",
      });
      return false;
    }

    try {
      // Check if there's already an active shift
      const { data: existingShifts, error: checkError } = await supabase
        .from('sessions')
        .select('id')
        .eq('user_id', user.id)
        .eq('status', 'active');

      if (checkError) {
        console.error('Error checking existing shift:', checkError);
        toast({
          title: "Error",
          description: "Failed to check for existing shift.",
          variant: "destructive",
        });
        return false;
      }

      if (existingShifts && existingShifts.length > 0) {
        toast({
          title: "Shift Already Active",
          description: "You already have an active shift running.",
          variant: "destructive",
        });
        return false;
      }

      // Create new shift
      const { data, error } = await supabase
        .from('sessions')
        .insert({
          user_id: user.id,
          status: 'active'
        })
        .select('id, user_id, start_time, status')
        .single();

      if (error) {
        console.error('Error starting shift:', error);
        toast({
          title: "Error",
          description: "Failed to start shift.",
          variant: "destructive",
        });
        return false;
      }

      setActiveShift(data);
      toast({
        title: "Shift Started",
        description: "Your shift has been started successfully.",
      });
      return true;

    } catch (error) {
      console.error('Error starting shift:', error);
      toast({
        title: "Error",
        description: "An unexpected error occurred.",
        variant: "destructive",
      });
      return false;
    }
  };

  const endShift = async (): Promise<boolean> => {
    if (!user || !activeShift) {
      toast({
        title: "Error",
        description: "No active shift to end.",
        variant: "destructive",
      });
      return false;
    }

    try {
      const { error } = await supabase
        .from('sessions')
        .update({
          status: 'ended',
          end_time: new Date().toISOString()
        })
        .eq('id', activeShift.id)
        .eq('status', 'active');

      if (error) {
        console.error('Error ending shift:', error);
        toast({
          title: "Error",
          description: "Failed to end shift.",
          variant: "destructive",
        });
        return false;
      }

      setActiveShift(null);
      toast({
        title: "Shift Ended",
        description: "Your shift has been ended successfully.",
      });
      return true;

    } catch (error) {
      console.error('Error ending shift:', error);
      toast({
        title: "Error",
        description: "An unexpected error occurred.",
        variant: "destructive",
      });
      return false;
    }
  };

  useEffect(() => {
    if (user) {
      checkActiveShift();
    } else {
      setActiveShift(null);
      setLoading(false);
    }
  }, [user]);

  const value: ShiftContextType = {
    activeShift,
    loading,
    startShift,
    endShift,
    checkActiveShift,
  };

  return (
    <ShiftContext.Provider value={value}>
      {children}
    </ShiftContext.Provider>
  );
};