import { useEffect, useState } from 'react';
import { useAuth } from '@/hooks/useAuth';

import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Package, 
  DollarSign, 
  TrendingUp, 
  AlertTriangle,
  Users,
  Clock,
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface DashboardStats {
  totalProducts: number;
  lowStockProducts: number;
  todaySales: number;
  todayRevenue: number;
  activeUsers: number;
  activeSessions: number;
}

const Dashboard = () => {
  const { profile } = useAuth();
  
  const { toast } = useToast();
  const [stats, setStats] = useState<DashboardStats>({
    totalProducts: 0,
    lowStockProducts: 0,
    todaySales: 0,
    todayRevenue: 0,
    activeUsers: 0,
    activeSessions: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardStats();
  }, []);

  const fetchDashboardStats = async () => {
    try {
      const today = new Date().toISOString().split('T')[0];

      // Fetch products stats
      const { data: products, error: productsError } = await supabase
        .from('products')
        .select('quantity, low_stock_threshold');

      if (productsError) throw productsError;

      const totalProducts = products?.length || 0;
      const lowStockProducts = products?.filter(p => p.quantity <= p.low_stock_threshold).length || 0;

      // Fetch today's sales
      const { data: todaySalesData, error: salesError } = await supabase
        .from('sales')
        .select('quantity, total_price')
        .gte('sale_time', `${today}T00:00:00.000Z`)
        .lt('sale_time', `${today}T23:59:59.999Z`);

      if (salesError) throw salesError;

      const todaySales = todaySalesData?.reduce((sum, sale) => sum + sale.quantity, 0) || 0;
      const todayRevenue = todaySalesData?.reduce((sum, sale) => sum + Number(sale.total_price), 0) || 0;

      // Fetch active sessions
      const { data: activeSessions, error: sessionsError } = await supabase
        .from('sessions')
        .select('id')
        .eq('status', 'active');

      if (sessionsError) throw sessionsError;

      // Fetch active users (users with active sessions)
      const { data: activeUsers, error: usersError } = await supabase
        .from('profiles')
        .select('id, user_id, sessions!inner(status)')
        .eq('sessions.status', 'active');

      if (usersError) throw usersError;

      setStats({
        totalProducts,
        lowStockProducts,
        todaySales,
        todayRevenue,
        activeUsers: activeUsers?.length || 0,
        activeSessions: activeSessions?.length || 0,
      });

      // Show low stock alert if applicable
      if (lowStockProducts > 0) {
        toast({
          title: "Low Stock Alert",
          description: `${lowStockProducts} product(s) are running low on stock.`,
          variant: "destructive",
        });
      }

    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
      toast({
        title: "Error",
        description: "Failed to load dashboard statistics.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const statCards = [
    {
      title: "Products in Stock",
      value: stats.totalProducts,
      icon: Package,
      description: "Total products available",
      color: "text-primary",
    },
    {
      title: "Low Stock Items",
      value: stats.lowStockProducts,
      icon: AlertTriangle,
      description: "Products need restocking",
      color: stats.lowStockProducts > 0 ? "text-destructive" : "text-muted-foreground",
    },
    {
      title: "Sales Today",
      value: stats.todaySales,
      icon: TrendingUp,
      description: "Items sold today",
      color: "text-success",
    },
    {
      title: "Revenue Today",
      value: `$${stats.todayRevenue.toFixed(2)}`,
      icon: DollarSign,
      description: "Total revenue today",
      color: "text-primary",
    },
    {
      title: "Active Sessions",
      value: stats.activeSessions,
      icon: Clock,
      description: "Currently active sessions",
      color: "text-info",
    },
    {
      title: "Active Users",
      value: stats.activeUsers,
      icon: Users,
      description: "Users currently online",
      color: "text-info",
    },
  ];

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-8 bg-muted rounded w-1/4"></div>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-32 bg-muted rounded-lg"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Welcome back, {profile?.full_name}
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <Badge variant="outline" className="capitalize">
            {profile?.role}
          </Badge>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {statCards.map((stat, index) => (
          <Card key={stat.title} className="medical-card hover:shadow-hover">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {stat.title}
              </CardTitle>
              <stat.icon className={`h-5 w-5 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${stat.color}`}>
                {stat.value}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {stat.description}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <AlertTriangle className="h-5 w-5 text-warning" />
              <span>System Status</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm">Database Connection</span>
              <Badge className="status-active">Online</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Inventory Sync</span>
              <Badge className="status-active">Up to Date</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Low Stock Alerts</span>
              <Badge className={stats.lowStockProducts > 0 ? "status-warning" : "status-active"}>
                {stats.lowStockProducts > 0 ? "Attention Needed" : "All Good"}
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5 text-success" />
              <span>Today's Summary</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm">Sales Transactions</span>
              <span className="font-medium">{stats.todaySales}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Revenue Generated</span>
              <span className="font-medium text-primary">${stats.todayRevenue.toFixed(2)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Active Sessions</span>
              <span className="font-medium">{stats.activeSessions}</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;