ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow users to read their own profile"
ON profiles
FOR SELECT
USING (auth.uid() = user_id);
