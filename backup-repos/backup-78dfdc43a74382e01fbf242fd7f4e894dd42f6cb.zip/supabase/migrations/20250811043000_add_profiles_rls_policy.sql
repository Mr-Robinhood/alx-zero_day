ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow users to read their own profile"
ON public.profiles FOR SELECT
TO authenticated
USING (auth.uid() = user_id);
