import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useShift } from '@/hooks/useShift';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  ShoppingCart, 
  Scan, 
  Plus, 
  Minus, 
  Trash2, 
  DollarSign,
  CreditCard,
  Receipt,
  Clock,
  Search,
  Printer
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Product {
  id: string;
  name: string;
  barcode: string;
  price: number;
  quantity: number;
}

interface CartItem extends Product {
  cartQuantity: number;
  subtotal: number;
}

interface Shift {
  id: string;
  status: string;
  start_time: string;
  end_time?: string;
  created_at?: string;
  user_id?: string;
}

const POS = () => {
  const { user, profile } = useAuth();
  const { activeShift } = useShift();
  const { toast } = useToast();
  const [products, setProducts] = useState<Product[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [barcode, setBarcode] = useState('');
  const [loading, setLoading] = useState(true);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'bank'>('cash');
  const [amountPaid, setAmountPaid] = useState<string>('');
  const [changeDue, setChangeDue] = useState<number>(0);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('name');

      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      console.error('Error fetching products:', error);
      toast({
        title: "Error",
        description: "Failed to load products.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };


  const addToCart = (product: Product) => {
    if (product.quantity <= 0) {
      toast({
        title: "Out of stock",
        description: `${product.name} is currently out of stock.`,
        variant: "destructive",
      });
      return;
    }

    const existingItem = cart.find(item => item.id === product.id);
    
    if (existingItem) {
      if (existingItem.cartQuantity >= product.quantity) {
        toast({
          title: "Insufficient stock",
          description: `Only ${product.quantity} units available.`,
          variant: "destructive",
        });
        return;
      }
      
      setCart(cart.map(item =>
        item.id === product.id
          ? { 
              ...item, 
              cartQuantity: item.cartQuantity + 1,
              subtotal: (item.cartQuantity + 1) * item.price
            }
          : item
      ));
    } else {
      setCart([...cart, {
        ...product,
        cartQuantity: 1,
        subtotal: product.price
      }]);
    }
  };

  const updateCartQuantity = (productId: string, newQuantity: number) => {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    if (newQuantity <= 0) {
      removeFromCart(productId);
      return;
    }

    if (newQuantity > product.quantity) {
      toast({
        title: "Insufficient stock",
        description: `Only ${product.quantity} units available.`,
        variant: "destructive",
      });
      return;
    }

    setCart(cart.map(item =>
      item.id === productId
        ? { 
            ...item, 
            cartQuantity: newQuantity,
            subtotal: newQuantity * item.price
          }
        : item
    ));
  };

  const removeFromCart = (productId: string) => {
    setCart(cart.filter(item => item.id !== productId));
  };

  const searchProduct = (term: string) => {
    const product = products.find(p => 
      p.barcode.toLowerCase().includes(term.toLowerCase()) ||
      p.name.toLowerCase().includes(term.toLowerCase())
    );
    
    if (product) {
      addToCart(product);
      setBarcode('');
      setSearchTerm('');
    } else {
      toast({
        title: "Product not found",
        description: "No product matches the search criteria.",
        variant: "destructive",
      });
    }
  };

  const processSale = async () => {
    if (!activeShift || cart.length === 0 || !user) return;

    const totalAmount = getTotalAmount();
    const paidAmount = paymentMethod === 'cash' ? parseFloat(amountPaid) || 0 : totalAmount;
    
    if (paymentMethod === 'cash' && paidAmount < totalAmount) {
      toast({
        title: "Insufficient payment",
        description: "Amount paid is less than the total amount.",
        variant: "destructive",
      });
      return;
    }

    setProcessing(true);

    try {
      // Create sale header
      const { data: saleData, error: saleError } = await supabase
        .from('sales')
        .insert({
          session_id: activeShift.id,
          user_id: user.id,
          product_id: cart[0].id, // Keep for backward compatibility
          quantity: cart.reduce((sum, item) => sum + item.cartQuantity, 0),
          unit_price: totalAmount / cart.reduce((sum, item) => sum + item.cartQuantity, 0),
          total_price: totalAmount,
          payment_method: paymentMethod,
          total_amount: totalAmount,
          amount_paid: paidAmount,
          change_due: paidAmount - totalAmount,
        })
        .select()
        .single();

      if (saleError) throw saleError;

      // Create sale items
      const saleItemsData = cart.map(item => ({
        sale_id: saleData.id,
        product_id: item.id,
        quantity: item.cartQuantity,
        unit_price: item.price,
        total_price: item.subtotal,
      }));

      const { error: saleItemsError } = await supabase
        .from('sale_items')
        .insert(saleItemsData);

      if (saleItemsError) throw saleItemsError;

      // Update product quantities
      for (const item of cart) {
        const { error: updateError } = await supabase
          .from('products')
          .update({ quantity: item.quantity - item.cartQuantity })
          .eq('id', item.id);

        if (updateError) throw updateError;
      }

      // Calculate change
      const change = paidAmount - totalAmount;
      setChangeDue(change);

      // Clear cart and refresh products
      setCart([]);
      setAmountPaid('');
      setIsCheckoutOpen(false);
      fetchProducts();

      toast({
        title: "Sale completed",
        description: `Transaction processed successfully. Total: $${totalAmount.toFixed(2)}${change > 0 ? `, Change: $${change.toFixed(2)}` : ''}`,
      });

    } catch (error) {
      console.error('Error processing sale:', error);
      toast({
        title: "Transaction failed",
        description: "Failed to process the sale. Please try again.",
        variant: "destructive",
      });
    } finally {
      setProcessing(false);
    }
  };

  const printReceipt = () => {
    const totalAmount = getTotalAmount();
    const paidAmount = paymentMethod === 'cash' ? parseFloat(amountPaid) || 0 : totalAmount;
    const change = paidAmount - totalAmount;

    const receiptContent = `
      ===== PHARMACY RECEIPT =====
      Date: ${new Date().toLocaleDateString()}
      Time: ${new Date().toLocaleTimeString()}
      Cashier: ${profile?.full_name || 'Unknown'}
      
      Items:
      ${cart.map(item => `${item.name} x${item.cartQuantity} - $${item.subtotal.toFixed(2)}`).join('\n      ')}
      
      -------------------------
      Total: $${totalAmount.toFixed(2)}
      Payment: ${paymentMethod.toUpperCase()}
      Amount Paid: $${paidAmount.toFixed(2)}
      ${change > 0 ? `Change: $${change.toFixed(2)}` : ''}
      
      ===== THANK YOU! =====
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head><title>Receipt</title></head>
          <body style="font-family: monospace; white-space: pre-line;">
            ${receiptContent}
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const getTotalAmount = () => {
    return cart.reduce((total, item) => total + item.subtotal, 0);
  };

  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.barcode.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-8 bg-muted rounded w-1/4"></div>
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 h-96 bg-muted rounded-lg"></div>
          <div className="h-96 bg-muted rounded-lg"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center space-x-3">
            <ShoppingCart className="h-8 w-8 text-primary" />
            <span>Point of Sale</span>
          </h1>
          <p className="text-muted-foreground mt-1">
            Process sales and manage transactions
          </p>
        </div>
         
        <div className="flex items-center space-x-3">
          {activeShift ? (
            <Badge className="status-active">
              <Clock className="h-3 w-3 mr-1" />
              Shift #{activeShift.id.slice(-8)} - {new Date(activeShift.start_time).toLocaleTimeString()}
            </Badge>
          ) : (
            <Badge variant="secondary" className="status-inactive">
              No Active Shift
            </Badge>
          )}
        </div>
      </div>

      {/* Main POS Interface */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Products Section */}
        <div className="lg:col-span-2 space-y-4">
          {/* Search and Barcode Scanner */}
          <Card className="medical-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Scan className="h-5 w-5" />
                <span>Product Search</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex space-x-2">
                <div className="flex-1">
                  <Label htmlFor="search">Search Products</Label>
                  <Input
                    id="search"
                    placeholder="Search by name..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    disabled={!activeShift}
                  />
                </div>
                <div className="flex-1">
                  <Label htmlFor="barcode">Barcode Scanner</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="barcode"
                      placeholder="Scan or enter barcode"
                      value={barcode}
                      onChange={(e) => setBarcode(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && searchProduct(barcode)}
                      disabled={!activeShift}
                    />
                    <Button 
                      onClick={() => searchProduct(barcode)}
                      disabled={!activeShift || !barcode}
                    >
                      <Search className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Products Grid */}
          <Card className="medical-card">
            <CardHeader>
              <CardTitle>Available Products</CardTitle>
              <CardDescription>
                Click to add products to cart
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="grid gap-3 md:grid-cols-2">
                  {filteredProducts.map((product) => (
                    <Card 
                      key={product.id} 
                      className={`cursor-pointer transition-all hover:shadow-md ${
                        !activeShift ? 'opacity-50' : ''
                      } ${product.quantity <= 0 ? 'opacity-40' : ''}`}
                      onClick={() => activeShift && addToCart(product)}
                    >
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <h4 className="font-medium text-sm">{product.name}</h4>
                            <p className="text-xs text-muted-foreground">{product.barcode}</p>
                            <p className="text-lg font-bold text-primary mt-1">
                              ${product.price.toFixed(2)}
                            </p>
                          </div>
                          <Badge 
                            variant={product.quantity > 0 ? "secondary" : "destructive"}
                            className="text-xs"
                          >
                            {product.quantity} in stock
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </div>

        {/* Cart Section */}
        <div className="space-y-4">
          <Card className="medical-card">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Shopping Cart</span>
                <Badge variant="outline">{cart.length} items</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-64">
                {cart.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">
                    Cart is empty
                  </p>
                ) : (
                  <div className="space-y-3">
                    {cart.map((item) => (
                      <div key={item.id} className="flex items-center space-x-2 p-2 border rounded">
                        <div className="flex-1">
                          <p className="font-medium text-sm">{item.name}</p>
                          <p className="text-xs text-muted-foreground">
                            ${item.price.toFixed(2)} each
                          </p>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => updateCartQuantity(item.id, item.cartQuantity - 1)}
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <span className="w-8 text-center text-sm">{item.cartQuantity}</span>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => updateCartQuantity(item.id, item.cartQuantity + 1)}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="destructive"
                            onClick={() => removeFromCart(item.id)}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                        <div className="text-right">
                          <p className="font-medium text-sm">${item.subtotal.toFixed(2)}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
              
              {cart.length > 0 && (
                <>
                  <Separator className="my-4" />
                  <div className="space-y-2">
                    <div className="flex justify-between text-lg font-bold">
                      <span>Total:</span>
                      <span className="text-primary">${getTotalAmount().toFixed(2)}</span>
                    </div>
                    <Dialog open={isCheckoutOpen} onOpenChange={setIsCheckoutOpen}>
                      <DialogTrigger asChild>
                        <Button 
                          className="w-full medical-gradient"
                          disabled={!activeShift || cart.length === 0}
                        >
                          <CreditCard className="h-4 w-4 mr-2" />
                          Checkout
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-md">
                        <DialogHeader>
                          <DialogTitle className="flex items-center space-x-2">
                            <Receipt className="h-5 w-5" />
                            <span>Complete Sale</span>
                          </DialogTitle>
                          <DialogDescription>
                            Review the transaction and process payment.
                          </DialogDescription>
                        </DialogHeader>
                         <div className="space-y-4">
                           <Table>
                             <TableHeader>
                               <TableRow>
                                 <TableHead>Item</TableHead>
                                 <TableHead>Qty</TableHead>
                                 <TableHead>Total</TableHead>
                               </TableRow>
                             </TableHeader>
                             <TableBody>
                               {cart.map((item) => (
                                 <TableRow key={item.id}>
                                   <TableCell className="font-medium">{item.name}</TableCell>
                                   <TableCell>{item.cartQuantity}</TableCell>
                                   <TableCell>${item.subtotal.toFixed(2)}</TableCell>
                                 </TableRow>
                               ))}
                             </TableBody>
                           </Table>
                           <Separator />
                           
                           {/* Payment Method Selection */}
                           <div className="space-y-2">
                             <Label htmlFor="paymentMethod">Payment Method</Label>
                             <Select 
                               value={paymentMethod} 
                               onValueChange={(value: 'cash' | 'bank') => setPaymentMethod(value)}
                             >
                               <SelectTrigger>
                                 <SelectValue placeholder="Select payment method" />
                               </SelectTrigger>
                               <SelectContent>
                                 <SelectItem value="cash">
                                   <div className="flex items-center space-x-2">
                                     <DollarSign className="h-4 w-4" />
                                     <span>Cash</span>
                                   </div>
                                 </SelectItem>
                                 <SelectItem value="bank">
                                   <div className="flex items-center space-x-2">
                                     <CreditCard className="h-4 w-4" />
                                     <span>Bank/Card</span>
                                   </div>
                                 </SelectItem>
                               </SelectContent>
                             </Select>
                           </div>

                           {/* Cash Payment Input */}
                           {paymentMethod === 'cash' && (
                             <div className="space-y-2">
                               <Label htmlFor="amountPaid">Amount Paid</Label>
                               <Input
                                 id="amountPaid"
                                 type="number"
                                 placeholder="Enter amount paid"
                                 value={amountPaid}
                                 onChange={(e) => setAmountPaid(e.target.value)}
                                 min={getTotalAmount()}
                                 step="0.01"
                               />
                               {amountPaid && parseFloat(amountPaid) >= getTotalAmount() && (
                                 <div className="text-sm">
                                   <span className="text-muted-foreground">Change due: </span>
                                   <span className="font-medium text-green-600">
                                     ${(parseFloat(amountPaid) - getTotalAmount()).toFixed(2)}
                                   </span>
                                 </div>
                               )}
                             </div>
                           )}

                           <Separator />
                           <div className="flex justify-between text-lg font-bold">
                             <span>Total Amount:</span>
                             <span className="text-primary">${getTotalAmount().toFixed(2)}</span>
                           </div>
                         </div>
                         <DialogFooter className="flex-col sm:flex-row gap-2">
                           <Button 
                             variant="outline" 
                             onClick={printReceipt}
                             disabled={cart.length === 0}
                           >
                             <Printer className="mr-2 h-4 w-4" />
                             Print Receipt
                           </Button>
                           <div className="flex gap-2">
                             <Button variant="outline" onClick={() => setIsCheckoutOpen(false)}>
                               Cancel
                             </Button>
                             <Button 
                               onClick={processSale}
                               className="medical-gradient" 
                               disabled={processing || (paymentMethod === 'cash' && (!amountPaid || parseFloat(amountPaid) < getTotalAmount()))}
                             >
                               {processing ? (
                                 <>
                                   <DollarSign className="mr-2 h-4 w-4 animate-spin" />
                                   Processing...
                                 </>
                               ) : (
                                 <>
                                   <DollarSign className="mr-2 h-4 w-4" />
                                   Complete Sale
                                 </>
                               )}
                             </Button>
                           </div>
                         </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default POS;