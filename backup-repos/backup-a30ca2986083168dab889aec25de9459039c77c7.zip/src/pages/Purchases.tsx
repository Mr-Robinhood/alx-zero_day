import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Plus, ShoppingCart, Package } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Purchase {
  id: string;
  company_id: string;
  product_id: string;
  quantity: number;
  unit_cost: number;
  total_cost: number;
  invoice_number: string | null;
  created_at: string;
  companies: { name: string };
  products: { name: string };
}

interface Company {
  id: string;
  name: string;
}

interface Product {
  id: string;
  name: string;
  barcode: string;
}

const Purchases = () => {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [showNewCompanyForm, setShowNewCompanyForm] = useState(false);
  
  const [purchaseForm, setPurchaseForm] = useState({
    company_id: '',
    product_id: '',
    quantity: '',
    unit_cost: '',
    invoice_number: '',
  });

  const [newCompanyForm, setNewCompanyForm] = useState({
    name: '',
    contact_person: '',
    email: '',
    phone: '',
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // Fetch purchases with company and product names
      const { data: purchasesData, error: purchasesError } = await supabase
        .from('purchases')
        .select(`
          *,
          companies(name),
          products(name)
        `)
        .order('created_at', { ascending: false });

      if (purchasesError) throw purchasesError;

      // Fetch companies
      const { data: companiesData, error: companiesError } = await supabase
        .from('companies')
        .select('id, name')
        .order('name');

      if (companiesError) throw companiesError;

      // Fetch products
      const { data: productsData, error: productsError } = await supabase
        .from('products')
        .select('id, name, barcode')
        .order('name');

      if (productsError) throw productsError;

      setPurchases(purchasesData || []);
      setCompanies(companiesData || []);
      setProducts(productsData || []);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast({
        title: "Error",
        description: "Failed to load data.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setPurchaseForm({
      company_id: '',
      product_id: '',
      quantity: '',
      unit_cost: '',
      invoice_number: '',
    });
    setNewCompanyForm({
      name: '',
      contact_person: '',
      email: '',
      phone: '',
    });
    setShowNewCompanyForm(false);
  };

  const handleCreateCompany = async () => {
    try {
      const { data, error } = await supabase
        .from('companies')
        .insert([{
          name: newCompanyForm.name,
          contact_person: newCompanyForm.contact_person || null,
          email: newCompanyForm.email || null,
          phone: newCompanyForm.phone || null,
        }])
        .select()
        .single();

      if (error) throw error;

      // Add new company to the list and select it
      setCompanies(prev => [...prev, data]);
      setPurchaseForm(prev => ({ ...prev, company_id: data.id }));
      setShowNewCompanyForm(false);
      setNewCompanyForm({ name: '', contact_person: '', email: '', phone: '' });

      toast({
        title: "Company created",
        description: `${newCompanyForm.name} has been added and selected.`,
      });
    } catch (error: any) {
      console.error('Error creating company:', error);
      toast({
        title: "Failed to create company",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      });
    }
  };

  const handleCreatePurchase = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreating(true);

    try {
      const totalCost = parseFloat(purchaseForm.unit_cost) * parseInt(purchaseForm.quantity);

      const { error } = await supabase
        .from('purchases')
        .insert([{
          company_id: purchaseForm.company_id,
          product_id: purchaseForm.product_id,
          quantity: parseInt(purchaseForm.quantity),
          unit_cost: parseFloat(purchaseForm.unit_cost),
          total_cost: totalCost,
          invoice_number: purchaseForm.invoice_number || null,
          user_id: profile?.user_id,
        }]);

      if (error) throw error;

      toast({
        title: "Purchase recorded successfully",
        description: "Inventory and company bill have been updated.",
      });

      resetForm();
      setIsDialogOpen(false);
      fetchData();
    } catch (error: any) {
      console.error('Error creating purchase:', error);
      toast({
        title: "Failed to record purchase",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setCreating(false);
    }
  };

  const openCreateDialog = () => {
    resetForm();
    setIsDialogOpen(true);
  };

  const totalCost = purchaseForm.unit_cost && purchaseForm.quantity 
    ? (parseFloat(purchaseForm.unit_cost) * parseInt(purchaseForm.quantity)).toFixed(2)
    : '0.00';

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-8 bg-muted rounded w-1/4"></div>
        <div className="h-96 bg-muted rounded-lg"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center space-x-3">
            <ShoppingCart className="h-8 w-8 text-primary" />
            <span>Purchases</span>
          </h1>
          <p className="text-muted-foreground mt-1">
            Record purchases and update inventory automatically
          </p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="medical-gradient" onClick={openCreateDialog}>
              <Plus className="h-4 w-4 mr-2" />
              Record Purchase
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-2">
                <ShoppingCart className="h-5 w-5" />
                <span>Record New Purchase</span>
              </DialogTitle>
              <DialogDescription>
                Record a new purchase to update inventory and company bill
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreatePurchase} className="space-y-4">
              {/* Company Selection */}
              <div className="space-y-2">
                <Label htmlFor="company">Company</Label>
                {!showNewCompanyForm ? (
                  <div className="flex space-x-2">
                    <Select value={purchaseForm.company_id} onValueChange={(value) => setPurchaseForm({ ...purchaseForm, company_id: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a company" />
                      </SelectTrigger>
                      <SelectContent>
                        {companies.map((company) => (
                          <SelectItem key={company.id} value={company.id}>
                            {company.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button type="button" variant="outline" onClick={() => setShowNewCompanyForm(true)}>
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3 p-4 border rounded-lg">
                    <div className="flex justify-between items-center">
                      <span className="font-medium">Add New Company</span>
                      <Button type="button" variant="ghost" size="sm" onClick={() => setShowNewCompanyForm(false)}>
                        Cancel
                      </Button>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <Input
                        placeholder="Company name"
                        value={newCompanyForm.name}
                        onChange={(e) => setNewCompanyForm({ ...newCompanyForm, name: e.target.value })}
                        required
                      />
                      <Input
                        placeholder="Contact person"
                        value={newCompanyForm.contact_person}
                        onChange={(e) => setNewCompanyForm({ ...newCompanyForm, contact_person: e.target.value })}
                      />
                      <Input
                        placeholder="Email"
                        type="email"
                        value={newCompanyForm.email}
                        onChange={(e) => setNewCompanyForm({ ...newCompanyForm, email: e.target.value })}
                      />
                      <Input
                        placeholder="Phone"
                        value={newCompanyForm.phone}
                        onChange={(e) => setNewCompanyForm({ ...newCompanyForm, phone: e.target.value })}
                      />
                    </div>
                    <Button type="button" onClick={handleCreateCompany} size="sm">
                      Add Company
                    </Button>
                  </div>
                )}
              </div>

              {/* Product Selection */}
              <div className="space-y-2">
                <Label htmlFor="product">Product</Label>
                <Select value={purchaseForm.product_id} onValueChange={(value) => setPurchaseForm({ ...purchaseForm, product_id: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a product" />
                  </SelectTrigger>
                  <SelectContent>
                    {products.map((product) => (
                      <SelectItem key={product.id} value={product.id}>
                        {product.name} ({product.barcode})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="quantity">Quantity</Label>
                  <Input
                    id="quantity"
                    type="number"
                    placeholder="100"
                    value={purchaseForm.quantity}
                    onChange={(e) => setPurchaseForm({ ...purchaseForm, quantity: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="unit_cost">Unit Cost ($)</Label>
                  <Input
                    id="unit_cost"
                    type="number"
                    step="0.01"
                    placeholder="5.99"
                    value={purchaseForm.unit_cost}
                    onChange={(e) => setPurchaseForm({ ...purchaseForm, unit_cost: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="invoice_number">Invoice Number (Optional)</Label>
                <Input
                  id="invoice_number"
                  type="text"
                  placeholder="INV-2024-001"
                  value={purchaseForm.invoice_number}
                  onChange={(e) => setPurchaseForm({ ...purchaseForm, invoice_number: e.target.value })}
                />
              </div>

              {/* Total Cost Display */}
              <div className="p-3 bg-accent rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="font-medium">Total Cost:</span>
                  <span className="text-lg font-bold text-primary">${totalCost}</span>
                </div>
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  className="medical-gradient" 
                  disabled={creating || !purchaseForm.company_id || !purchaseForm.product_id}
                >
                  {creating ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Recording...
                    </>
                  ) : (
                    'Record Purchase'
                  )}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid gap-6 md:grid-cols-3">
        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Purchases
            </CardTitle>
            <ShoppingCart className="h-5 w-5 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">
              {purchases.length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Purchase records
            </p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Value
            </CardTitle>
            <Package className="h-5 w-5 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-success">
              ${purchases.reduce((total, purchase) => total + Number(purchase.total_cost), 0).toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              All purchases
            </p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              This Month
            </CardTitle>
            <ShoppingCart className="h-5 w-5 text-info" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-info">
              {purchases.filter(p => {
                const purchaseDate = new Date(p.created_at);
                const currentDate = new Date();
                return purchaseDate.getMonth() === currentDate.getMonth() && 
                       purchaseDate.getFullYear() === currentDate.getFullYear();
              }).length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Purchases this month
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Purchases Table */}
      <Card className="medical-card">
        <CardHeader>
          <CardTitle>Purchase History</CardTitle>
          <CardDescription>
            All recorded purchases and their details
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Company</TableHead>
                <TableHead>Product</TableHead>
                <TableHead>Quantity</TableHead>
                <TableHead>Unit Cost</TableHead>
                <TableHead>Total Cost</TableHead>
                <TableHead>Invoice</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {purchases.map((purchase) => (
                <TableRow key={purchase.id}>
                  <TableCell>
                    {new Date(purchase.created_at).toLocaleDateString()}
                  </TableCell>
                  <TableCell className="font-medium">
                    {purchase.companies?.name}
                  </TableCell>
                  <TableCell>
                    {purchase.products?.name}
                  </TableCell>
                  <TableCell>{purchase.quantity}</TableCell>
                  <TableCell>${Number(purchase.unit_cost).toFixed(2)}</TableCell>
                  <TableCell className="font-medium">
                    ${Number(purchase.total_cost).toFixed(2)}
                  </TableCell>
                  <TableCell>
                    {purchase.invoice_number || (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default Purchases;